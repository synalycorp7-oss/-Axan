"""Axan server: machine API + dashboard.

Run:  uvicorn axan_server.app:app --host 0.0.0.0 --port 8000
Env:  AXAN_DB (sqlite path), AXAN_ADMIN_PASSWORD (protects the dashboard),
      AXAN_SMS_WEBHOOK + AXAN_MANAGER_PHONE (alert SMS), AXAN_DEPOT_LAT/LON.
"""
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
import secrets
from datetime import date, datetime, timedelta

from fastapi import Depends, FastAPI, Form, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field

from . import dashboard, db
from .ai import forecast
from .analysis import analyze

app = FastAPI(title="Axan", version="0.1.0", description="Mobile-money vending machines for discreet access to contraception and menstrual products.")
_conn = None
security = HTTPBasic(auto_error=False)


def conn():
    global _conn
    if _conn is None:
        _conn = db.connect()
    return _conn


def admin(creds: HTTPBasicCredentials | None = Depends(security)):
    pw = os.environ.get("AXAN_ADMIN_PASSWORD")
    if not pw:
        return "admin"
    if creds is None or not secrets.compare_digest(creds.password, pw):
        raise HTTPException(401, headers={"WWW-Authenticate": "Basic"})
    return creds.username or "admin"


def lang_of(request: Request) -> str:
    q = request.query_params.get("lang")
    if q in dashboard.T:
        return q
    return "fr" if request.headers.get("accept-language", "").lower().startswith("fr") else "en"


# ---------------------------------------------------------------- machine API

class Event(BaseModel):
    seq: int
    type: str
    ts: str | None = ""
    uptime: int | None = None
    slot: int | None = None
    amount: int | None = None
    ref: str | None = Field(None, max_length=40)
    payer: str | None = Field(None, max_length=16)
    detail: str | None = Field(None, max_length=40)
    stock: list[int] | None = None


class Batch(BaseModel):
    machine_id: str
    events: list[Event] = Field(max_length=200)


@app.post("/api/v1/events")
def post_events(batch: Batch, x_api_key: str = Header("")):
    c = conn()
    if not db.check_key(c, batch.machine_id, x_api_key):
        raise HTTPException(401, "invalid machine or API key")
    n = db.ingest(c, batch.machine_id, [e.model_dump() for e in batch.events])
    return {"ok": True, "stored": n}


# ---------------------------------------------------------------- JSON for partners / health system

@app.get("/api/v1/snapshot")
def snapshot(_=Depends(admin)):
    return analyze(conn())


@app.get("/api/v1/open-data/daily")
def open_data(days: int = 30, _=Depends(admin)):
    """Aggregated, anonymous demand per machine and day (for health programmes)."""
    since = (date.today() - timedelta(days=min(days, 365))).isoformat()
    rows = conn().execute(
        "SELECT machine_id, substr(ts,1,10) AS day, slot, COUNT(*) AS units FROM events "
        "WHERE type='sale' AND ts>=? GROUP BY machine_id, day, slot ORDER BY day", (since,)).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------- dashboard

def open_alerts(c):
    return [dict(r) for r in c.execute(
        "SELECT * FROM alerts WHERE status='open' ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'serious' THEN 1 ELSE 2 END, created DESC")]


@app.get("/", response_class=HTMLResponse)
def home(request: Request, _=Depends(admin)):
    c = conn()
    snap = analyze(c)
    return dashboard.overview(snap, open_alerts(c), lang_of(request))


@app.get("/machine/{machine_id}", response_class=HTMLResponse)
def machine(machine_id: str, request: Request, _=Depends(admin)):
    c = conn()
    snap = analyze(c, persist_alerts=False)
    m = next((x for x in snap["machines"] if x["id"] == machine_id), None)
    if not m:
        raise HTTPException(404)
    today = datetime.fromisoformat(snap["generated"]).date()
    histories, forecasts = {}, {}
    for s in m["slots"]:
        rows = {r["d"]: r["n"] for r in c.execute(
            "SELECT substr(ts,1,10) d, COUNT(*) n FROM events WHERE machine_id=? AND type='sale' AND slot=? AND ts>=? GROUP BY d",
            (machine_id, s["index"], (today - timedelta(days=60)).isoformat()))}
        histories[s["index"]] = {(today - timedelta(days=i)).isoformat(): rows.get((today - timedelta(days=i)).isoformat(), 0) for i in range(21, 0, -1)}
        model = forecast.fit({date.fromisoformat(d): n for d, n in rows.items() if d < today.isoformat()}, today)
        forecasts[s["index"]] = model.forecast(today, 14)
    return dashboard.machine_page(m, histories, forecasts, lang_of(request))


@app.post("/alerts/{alert_id}/review")
def review(alert_id: int, request: Request, action: str = Form(...), user=Depends(admin)):
    if action not in ("validated", "dismissed"):
        raise HTTPException(400)
    c = conn()
    c.execute("UPDATE alerts SET status=?, reviewed_by=?, reviewed_at=? WHERE id=?", (action, user, db.now_iso(), alert_id))
    c.commit()
    return RedirectResponse(f"/?lang={lang_of(request)}", status_code=303)


@app.get("/health")
def health():
    return {"ok": True}
