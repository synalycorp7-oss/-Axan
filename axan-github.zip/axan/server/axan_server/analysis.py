"""Builds the network snapshot used by the dashboard and the JSON API:
stock, forecasts, anomalies, alerts, refill route and impact indicators."""
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import os
from datetime import date, datetime, timedelta

from .ai import anomalies, forecast, routing
from .db import now_iso

HEARTBEAT_MIN = 15
REFILL_WITHIN_DAYS = 2.0
DEPOT = (float(os.environ.get("AXAN_DEPOT_LAT", 12.3714)), float(os.environ.get("AXAN_DEPOT_LON", -1.5197)))  # Ouagadougou


def _dt(s: str) -> datetime:
    return datetime.fromisoformat(s[:19])


def _off_hours(t: datetime) -> bool:
    """Night (20:00-07:00) or weekend: when most pharmacies are closed."""
    return t.hour >= 20 or t.hour < 7 or t.weekday() >= 5


def analyze(conn, now: datetime | None = None, persist_alerts: bool = True) -> dict:
    now = now or datetime.fromisoformat(now_iso())
    today = now.date()
    since15 = (now - timedelta(days=15)).isoformat()
    since30 = (now - timedelta(days=30)).isoformat()
    machines = []
    findings: list[anomalies.Finding] = []

    for m in conn.execute("SELECT * FROM machines ORDER BY id").fetchall():
        mid, products = m["id"], json.loads(m["products"])
        last = conn.execute("SELECT ts, stock FROM events WHERE machine_id=? AND stock IS NOT NULL ORDER BY ts DESC, seq DESC LIMIT 1", (mid,)).fetchone()
        stock = json.loads(last["stock"]) if last else [0] * len(products)
        seen = conn.execute("SELECT MAX(ts) AS t FROM events WHERE machine_id=?", (mid,)).fetchone()["t"]

        # Slot faults: a failed dispense not followed by a refill/test of that slot.
        faults = set()
        for r in conn.execute("SELECT type, slot FROM events WHERE machine_id=? AND type IN ('dispense_failed','refill','test_dispense') ORDER BY ts, seq", (mid,)):
            if r["type"] == "dispense_failed" and r["slot"] is not None and r["slot"] >= 0:
                faults.add(r["slot"])
            elif r["slot"] in faults:
                faults.discard(r["slot"])

        slots = []
        for i, p in enumerate(products):
            hist = {date.fromisoformat(r["d"]): r["n"] for r in conn.execute(
                "SELECT substr(ts,1,10) AS d, COUNT(*) AS n FROM events WHERE machine_id=? AND type='sale' AND slot=? AND ts<? GROUP BY d",
                (mid, i, today.isoformat()))}
            model = forecast.fit(hist, today)
            s = stock[i] if i < len(stock) else 0
            dte = forecast.days_until_empty(model, s, today)
            bt = forecast.backtest(hist, today)
            slots.append({
                "index": i, "name": p["name"], "price": p["price"], "capacity": p["capacity"], "stock": s,
                "fault": i in faults, "method": model.method, "per_day": round(model.predict(today), 1),
                "days_to_empty": dte,
                "refill_by": (today + timedelta(days=max(0.0, (dte or 99) - 1))).isoformat() if dte is not None else None,
                "backtest": bt.__dict__ | {"improvement": round(bt.improvement, 2)} if bt else None,
            })

        recent = [{"t": _dt(r["ts"]), "type": r["type"], "ref": r["ref"]} for r in conn.execute(
            "SELECT ts, type, ref FROM events WHERE machine_id=? AND ts>=?", (mid, since15))]
        has_stock = all(s["stock"] > 0 for s in slots)
        f = anomalies.detect(mid, recent, now, has_stock)
        for s in slots:
            if s["days_to_empty"] is not None and s["days_to_empty"] <= REFILL_WITHIN_DAYS:
                f.append(anomalies.Finding(mid, "stock_out_soon", "warning" if s["stock"] > 0 else "serious",
                                           f"{s['name']}: {s['stock']} left, empty in ~{s['days_to_empty']} day(s).",
                                           {"slot": s["index"], "name": s["name"], "stock": s["stock"], "days": s["days_to_empty"]}))
        findings += f

        # Availability over 30 days = share of expected heartbeats received with every slot stocked.
        first = conn.execute("SELECT MIN(ts) AS t FROM events WHERE machine_id=?", (mid,)).fetchone()["t"]
        start = max(now - timedelta(days=30), _dt(first)) if first else now
        expected = max(1, int((now - start).total_seconds() // (HEARTBEAT_MIN * 60)))
        ok = 0
        for r in conn.execute("SELECT stock FROM events WHERE machine_id=? AND type='heartbeat' AND ts>=?", (mid, start.isoformat())):
            st = json.loads(r["stock"] or "[]")
            ok += bool(st) and all(x > 0 for x in st)
        sales30 = conn.execute("SELECT COUNT(*) AS n FROM events WHERE machine_id=? AND type='sale' AND ts>=?", (mid, since30)).fetchone()["n"]

        kinds = {x.kind for x in f}
        status = "critical" if kinds & {"probable_breakdown", "dispense_failures"} or faults else \
                 "offline" if "offline" in kinds else \
                 "warning" if kinds & {"stock_out_soon", "fraud_attempts", "refund_needed"} else "good"
        machines.append({
            "id": mid, "name": m["name"], "site_type": m["site_type"], "lat": m["lat"], "lon": m["lon"],
            "last_seen": seen, "status": status, "slots": slots, "sales_30d": sales30,
            "availability_30d": round(min(1.0, ok / expected), 3),
        })

    if persist_alerts:
        _sync_alerts(conn, findings, now)

    # Refill route: machines with a slot empty soon, empty, or faulty.
    need = {m["id"]: (m["lat"], m["lon"]) for m in machines if m["lat"] is not None and any(
        s["fault"] or s["stock"] == 0 or (s["days_to_empty"] is not None and s["days_to_empty"] <= REFILL_WITHIN_DAYS)
        for s in m["slots"])}
    order, km = routing.plan_route(DEPOT, need)

    # Network-wide indicators (30 days).
    sales = [_dt(r["ts"]) for r in conn.execute("SELECT ts FROM events WHERE type='sale' AND ts>=?", (since30,))]
    daily = {(today - timedelta(days=i)).isoformat(): 0 for i in range(30, 0, -1)}
    hourly = [0] * 24
    for t in sales:
        if t.date().isoformat() in daily:
            daily[t.date().isoformat()] += 1
        hourly[t.hour] += 1
    blocked = conn.execute("SELECT COUNT(*) AS n FROM events WHERE type IN ('sms_rejected','replay_blocked') AND ts>=?", (since30,)).fetchone()["n"]
    bts = [s["backtest"] for m in machines for s in m["slots"] if s["backtest"]]
    mae_m = sum(b["mae_model"] for b in bts) / len(bts) if bts else None
    mae_n = sum(b["mae_naive"] for b in bts) / len(bts) if bts else None

    return {
        "generated": now.isoformat(timespec="minutes"),
        "machines": machines,
        "findings": [x.__dict__ for x in findings],
        "route": {"depot": DEPOT, "stops": order, "km": km},
        "kpis": {
            "sales_30d": len(sales),
            "availability_30d": round(sum(m["availability_30d"] for m in machines) / len(machines), 3) if machines else None,
            "off_hours_share": round(sum(_off_hours(t) for t in sales) / len(sales), 3) if sales else None,
            "fraud_blocked_30d": blocked,
            "forecast_mae": round(mae_m, 2) if mae_m is not None else None,
            "naive_mae": round(mae_n, 2) if mae_n is not None else None,
        },
        "daily_sales": daily,
        "hourly_sales": hourly,
    }


def _sync_alerts(conn, findings, now: datetime):
    """One open alert per (machine, kind). Reviewed alerts are not re-raised for 12 h."""
    cutoff = (now - timedelta(hours=12)).isoformat()
    for f in findings:
        exists = conn.execute(
            "SELECT 1 FROM alerts WHERE machine_id=? AND kind=? AND (status='open' OR reviewed_at>=?)",
            (f.machine_id, f.kind, cutoff)).fetchone()
        if not exists:
            conn.execute("INSERT INTO alerts(machine_id,created,kind,severity,message,data) VALUES(?,?,?,?,?,?)",
                         (f.machine_id, now.isoformat(timespec="seconds"), f.kind, f.severity, f.message, json.dumps(f.data, default=str)))
            notify(f)
    conn.commit()


def notify(f):
    """Send an SMS to the field manager through an SMS gateway webhook if configured."""
    url = os.environ.get("AXAN_SMS_WEBHOOK")
    if not url or f.severity == "warning":
        return
    try:
        import urllib.request
        body = json.dumps({"to": os.environ.get("AXAN_MANAGER_PHONE", ""), "text": f"Axan {f.machine_id}: {f.message}"[:160]}).encode()
        urllib.request.urlopen(urllib.request.Request(url, body, {"Content-Type": "application/json"}), timeout=5)
    except Exception as exc:  # never break analysis because of the SMS gateway
        print("SMS notify failed:", exc)
