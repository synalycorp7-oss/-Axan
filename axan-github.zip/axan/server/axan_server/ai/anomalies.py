"""Anomaly detection on machine events.

Every finding is a *recommendation* shown to a human, who validates or dismisses
it on the dashboard. Nothing is blocked or changed automatically on the server.
"""
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta

OFFLINE_AFTER = timedelta(hours=2)        # heartbeat every 15 min -> 8 missed beats
DROP_P_VALUE = 0.01                       # sales this low happen < 1% of the time by chance
DROP_MIN_EXPECTED = 4.0                   # don't judge machines that normally sell very little
FAIL_RATE = 0.2
FRAUD_MIN_EVENTS = 3


@dataclass
class Finding:
    machine_id: str
    kind: str          # offline | probable_breakdown | dispense_failures | fraud_attempts | refund_needed | stock_out_soon
    severity: str      # critical | serious | warning
    message: str
    data: dict


def poisson_cdf(k: int, lam: float) -> float:
    """P(X <= k) for X ~ Poisson(lam)."""
    if lam <= 0:
        return 1.0
    term = math.exp(-lam)
    total = term
    for i in range(1, k + 1):
        term *= lam / i
        total += term
    return min(1.0, total)


def expected_24h(sale_times: list[datetime], now: datetime, windows: int = 14) -> float:
    """Mean number of sales in the 24h windows preceding the current one."""
    counts = [0] * windows
    for t in sale_times:
        age = now - t
        k = int(age.total_seconds() // 86400)
        if 1 <= k <= windows:
            counts[k - 1] += 1
    return sum(counts) / windows


def detect(machine_id: str, events: list[dict], now: datetime, has_stock: bool) -> list[Finding]:
    """`events`: this machine's events of the last 15 days, each with a datetime `t` and a `type`."""
    out: list[Finding] = []
    if not events:
        return [Finding(machine_id, "offline", "serious", "No data received from this machine yet.", {})]

    last_seen = max(e["t"] for e in events)
    if now - last_seen > OFFLINE_AFTER:
        hours = round((now - last_seen).total_seconds() / 3600, 1)
        out.append(Finding(machine_id, "offline", "serious",
                           f"No signal for {hours} h (power cut, GSM network or theft). Check on site.",
                           {"last_seen": last_seen.isoformat(), "hours": hours}))

    day = now - timedelta(hours=24)
    recent = [e for e in events if e["t"] > day]
    sales = [e["t"] for e in events if e["type"] == "sale"]
    obs = sum(1 for t in sales if t > day)
    lam = expected_24h(sales, now)

    # Silent breakdown: the machine is online and stocked but sells abnormally little.
    online = now - last_seen <= OFFLINE_AFTER
    if online and has_stock and lam >= DROP_MIN_EXPECTED:
        p = poisson_cdf(obs, lam)
        if p < DROP_P_VALUE:
            out.append(Finding(machine_id, "probable_breakdown", "critical",
                               f"Only {obs} sale(s) in 24 h vs {lam:.1f} expected (p={p:.4f}). "
                               "Payment or dispensing may be broken.",
                               {"observed": obs, "expected": round(lam, 1), "p": p}))

    fails = sum(1 for e in recent if e["type"] == "dispense_failed")
    if fails >= 2 and fails / max(1, fails + obs) >= FAIL_RATE:
        out.append(Finding(machine_id, "dispense_failures", "critical",
                           f"{fails} failed dispenses in 24 h: mechanism jammed or empty. Customers to refund.",
                           {"failures": fails}))

    fraud = [e for e in recent if e["type"] in ("sms_rejected", "replay_blocked")]
    if len(fraud) >= FRAUD_MIN_EVENTS:
        out.append(Finding(machine_id, "fraud_attempts", "serious",
                           f"{len(fraud)} fake or replayed payment SMS blocked in 24 h.",
                           {"count": len(fraud)}))

    mism = [e for e in recent if e["type"] == "amount_mismatch"]
    if mism:
        out.append(Finding(machine_id, "refund_needed", "warning",
                           f"{len(mism)} payment(s) with a wrong amount: refund or deliver manually.",
                           {"n": len(mism), "refs": [e.get("ref") for e in mism]}))
    return out
