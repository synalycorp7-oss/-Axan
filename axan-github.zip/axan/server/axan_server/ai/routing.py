"""Refill route: nearest-neighbour tour improved with 2-opt (fine for tens of machines)."""
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import math


def haversine_km(a: tuple[float, float], b: tuple[float, float]) -> float:
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6371 * math.asin(math.sqrt(h))


def _length(points, order):
    return sum(haversine_km(points[order[i]], points[order[i + 1]]) for i in range(len(order) - 1))


def plan_route(depot: tuple[float, float], stops: dict[str, tuple[float, float]]) -> tuple[list[str], float]:
    """Returns (ordered stop ids, total km) for a round trip depot -> stops -> depot."""
    if not stops:
        return [], 0.0
    ids = list(stops)
    points = [depot] + [stops[i] for i in ids]
    order, left = [0], set(range(1, len(points)))
    while left:
        nxt = min(left, key=lambda j: haversine_km(points[order[-1]], points[j]))
        order.append(nxt)
        left.remove(nxt)
    order.append(0)
    improved = True
    while improved:
        improved = False
        for i in range(1, len(order) - 2):
            for k in range(i + 1, len(order) - 1):
                new = order[:i] + order[i:k + 1][::-1] + order[k + 1:]
                if _length(points, new) + 1e-9 < _length(points, order):
                    order, improved = new, True
    return [ids[j - 1] for j in order[1:-1]], round(_length(points, order), 1)
