"""Axan AI modules: demand forecasting, anomaly detection, refill routing."""
