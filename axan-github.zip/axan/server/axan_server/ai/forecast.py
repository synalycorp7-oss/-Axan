"""Demand forecasting per machine and product.

Model (deliberately small, explainable, CPU-only, no external ML dependency):
    expected(day) = level x weekday_factor[weekday] x payday_factor[is_payday]
  - level: exponential smoothing of the de-seasonalised daily sales
  - factors: learned from history with shrinkage toward 1 (robust with little data)
  - cold start (< MIN_DAYS of history): simple rule = mean of recent days, or a default rate
The model is backtested on the last 7 days and compared with a naive baseline,
so accuracy is measured, reported on the dashboard and checked every week.
"""
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta

MIN_DAYS = 14
ALPHA = 0.25          # smoothing of the level
SHRINK = 3.0          # pseudo-observations pulling factors toward 1
DEFAULT_RATE = 2.0    # sales/day assumed for a brand-new machine


def is_payday(d: date) -> bool:
    """Salaries in Burkina Faso are mostly paid at month end; demand rises around it."""
    return d.day >= 25 or d.day <= 3


@dataclass
class Model:
    method: str                  # "model" or "rules"
    level: float
    weekday: list[float] = field(default_factory=lambda: [1.0] * 7)
    payday: float = 1.0
    n_days: int = 0

    def predict(self, d: date) -> float:
        f = self.weekday[d.weekday()] * (self.payday if is_payday(d) else 1.0)
        return max(0.0, self.level * f)

    def forecast(self, start: date, horizon: int) -> list[tuple[date, float]]:
        return [(start + timedelta(days=i), self.predict(start + timedelta(days=i))) for i in range(horizon)]


def _dense(history: dict[date, int], end: date) -> list[tuple[date, int]]:
    """Daily series from first observed day to `end` (exclusive), zeros filled."""
    if not history:
        return []
    d, out = min(history), []
    while d < end:
        out.append((d, history.get(d, 0)))
        d += timedelta(days=1)
    return out


def _factor(values: list[float], overall: float) -> float:
    if not values or overall <= 0:
        return 1.0
    raw = (sum(values) / len(values)) / overall
    return (len(values) * raw + SHRINK) / (len(values) + SHRINK)


def fit(history: dict[date, int], end: date) -> Model:
    series = _dense(history, end)
    if len(series) < MIN_DAYS:
        recent = [v for _, v in series[-7:]]
        rate = sum(recent) / len(recent) if recent else DEFAULT_RATE
        return Model(method="rules", level=rate, n_days=len(series))

    overall = sum(v for _, v in series) / len(series)
    weekday = [_factor([v for d, v in series if d.weekday() == w], overall) for w in range(7)]
    pay = _factor([v for d, v in series if is_payday(d)], overall) / max(
        _factor([v for d, v in series if not is_payday(d)], overall), 1e-6)

    level = None
    for d, v in series:
        f = weekday[d.weekday()] * (pay if is_payday(d) else 1.0)
        x = v / f if f > 0 else v
        level = x if level is None else ALPHA * x + (1 - ALPHA) * level
    return Model(method="model", level=level or 0.0, weekday=weekday, payday=pay, n_days=len(series))


@dataclass
class Backtest:
    mae_model: float
    mae_naive: float
    days: int

    @property
    def improvement(self) -> float:
        return 0.0 if self.mae_naive == 0 else 1 - self.mae_model / self.mae_naive


def backtest(history: dict[date, int], end: date, days: int = 7) -> Backtest | None:
    """Fit on data before the last `days`, compare with what really happened.
    Baseline = 'same as the average of the previous 7 days' (what a manager would guess)."""
    cut = end - timedelta(days=days)
    train = {d: v for d, v in history.items() if d < cut}
    if len(_dense(train, cut)) < MIN_DAYS:
        return None
    m = fit(train, cut)
    prev = [history.get(cut - timedelta(days=i), 0) for i in range(1, 8)]
    naive = sum(prev) / 7
    actual = [(cut + timedelta(days=i), history.get(cut + timedelta(days=i), 0)) for i in range(days)]
    mae_m = sum(abs(m.predict(d) - v) for d, v in actual) / days
    mae_n = sum(abs(naive - v) for _, v in actual) / days
    return Backtest(round(mae_m, 2), round(mae_n, 2), days)


def days_until_empty(model: Model, stock: int, today: date, horizon: int = 60) -> float | None:
    """Fractional number of days until `stock` units are sold. None if beyond horizon."""
    if stock <= 0:
        return 0.0
    left = float(stock)
    for i, (_, q) in enumerate(model.forecast(today, horizon)):
        if q >= left:
            return round(i + left / q, 1) if q > 0 else None
        left -= q
    return None
