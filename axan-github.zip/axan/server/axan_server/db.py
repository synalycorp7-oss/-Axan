"""SQLite storage. No personal data is stored: payer numbers arrive already hashed by the machine."""
# SPDX-License-Identifier: Apache-2.0
import hashlib
import json
import os
import secrets
import sqlite3
from datetime import datetime, timezone

DEFAULT_PRODUCTS = [
    {"name": "Condoms x3", "price": 300, "capacity": 50},
    {"name": "Female condom", "price": 500, "capacity": 40},
    {"name": "Sanitary pads", "price": 500, "capacity": 40},
]

SCHEMA = """
CREATE TABLE IF NOT EXISTS machines (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  site_type TEXT,
  lat REAL, lon REAL,
  api_key_hash TEXT NOT NULL,
  products TEXT NOT NULL,
  created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY,
  machine_id TEXT NOT NULL REFERENCES machines(id),
  seq INTEGER NOT NULL,
  ts TEXT NOT NULL,
  received TEXT NOT NULL,
  type TEXT NOT NULL,
  slot INTEGER,
  amount INTEGER,
  ref TEXT,
  payer TEXT,
  detail TEXT,
  stock TEXT,
  UNIQUE(machine_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_events_machine_ts ON events(machine_id, ts);
CREATE INDEX IF NOT EXISTS idx_events_type_ts ON events(type, ts);
CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY,
  machine_id TEXT NOT NULL,
  created TEXT NOT NULL,
  kind TEXT NOT NULL,
  severity TEXT NOT NULL,
  message TEXT NOT NULL,
  data TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  reviewed_by TEXT,
  reviewed_at TEXT
);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(tzinfo=None).isoformat(timespec="seconds")


def db_path() -> str:
    return os.environ.get("AXAN_DB", os.path.join(os.getcwd(), "axan.db"))


def connect(path: str | None = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or db_path(), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA)
    return conn


def hash_key(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def add_machine(conn, machine_id, name, site_type="", lat=None, lon=None, products=None, api_key=None) -> str:
    api_key = api_key or secrets.token_urlsafe(18)
    conn.execute(
        "INSERT OR REPLACE INTO machines(id,name,site_type,lat,lon,api_key_hash,products,created) VALUES(?,?,?,?,?,?,?,?)",
        (machine_id, name, site_type, lat, lon, hash_key(api_key), json.dumps(products or DEFAULT_PRODUCTS), now_iso()),
    )
    conn.commit()
    return api_key


def check_key(conn, machine_id: str, api_key: str) -> bool:
    row = conn.execute("SELECT api_key_hash FROM machines WHERE id=?", (machine_id,)).fetchone()
    return bool(row) and secrets.compare_digest(row["api_key_hash"], hash_key(api_key or ""))


def machines(conn) -> list[dict]:
    out = []
    for r in conn.execute("SELECT * FROM machines ORDER BY id"):
        d = dict(r)
        d["products"] = json.loads(d["products"])
        d.pop("api_key_hash")
        out.append(d)
    return out


ALLOWED_TYPES = {
    "boot", "heartbeat", "sale", "dispense_failed", "sms_rejected", "sms_unparsed",
    "replay_blocked", "amount_mismatch", "refill", "test_dispense",
}


def ingest(conn, machine_id: str, events: list[dict], received: str | None = None) -> int:
    """Store events idempotently (machine_id, seq). Returns number of new rows."""
    received = received or now_iso()
    rows = []
    for e in events:
        etype = str(e.get("type", ""))
        if etype not in ALLOWED_TYPES:
            continue
        ts = str(e.get("ts") or "") or received  # clock not synced yet -> server time
        stock = e.get("stock")
        rows.append((
            machine_id, int(e["seq"]), ts[:19], received, etype,
            e.get("slot"), e.get("amount"), e.get("ref"),
            # Defence in depth: only accept 16-hex-char hashed payer IDs, never phone numbers.
            e.get("payer") if _is_hash(e.get("payer")) else None,
            e.get("detail"), json.dumps(stock) if isinstance(stock, list) else None,
        ))
    before = conn.total_changes
    conn.executemany(
        "INSERT OR IGNORE INTO events(machine_id,seq,ts,received,type,slot,amount,ref,payer,detail,stock) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        rows,
    )
    conn.commit()
    return conn.total_changes - before


def _is_hash(v) -> bool:
    return isinstance(v, str) and len(v) == 16 and all(c in "0123456789abcdef" for c in v)
