"""Admin commands.
  python -m axan_server.manage add-machine AXN-OUA-001 "Université Joseph Ki-Zerbo" --lat 12.3786 --lon -1.4967 --site university
  python -m axan_server.manage list
"""
# SPDX-License-Identifier: Apache-2.0
import argparse

from . import db


def main(argv=None):
    p = argparse.ArgumentParser(prog="axan_server.manage")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add-machine")
    a.add_argument("id")
    a.add_argument("name")
    a.add_argument("--lat", type=float)
    a.add_argument("--lon", type=float)
    a.add_argument("--site", default="")
    sub.add_parser("list")
    args = p.parse_args(argv)
    c = db.connect()
    if args.cmd == "add-machine":
        key = db.add_machine(c, args.id, args.name, args.site, args.lat, args.lon)
        print(f"Machine {args.id} registered.\nAPI_KEY (put it in firmware config.h, shown once): {key}")
    else:
        for m in db.machines(c):
            print(f"{m['id']:<14} {m['name']:<40} {m['lat']},{m['lon']}")


if __name__ == "__main__":
    main()
