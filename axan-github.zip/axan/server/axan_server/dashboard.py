"""Server-rendered dashboard (no JavaScript framework, no CDN: works on a local
network and on low-end phones). English / French."""
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import html
import json
from datetime import date, timedelta

T = {
    "en": {
        "title": "Axan network", "availability": "Machine availability", "target": "target 95%",
        "dispensed": "Products dispensed", "days30": "last 30 days", "offhours": "Bought at night or weekend",
        "offhours_sub": "when pharmacies are closed", "fraud": "Fraud attempts blocked", "accuracy": "Forecast error",
        "accuracy_sub": "units/day · model {m} vs naive {n}", "alerts": "Alerts to review", "noalerts": "No open alert.",
        "validate": "Done", "dismiss": "Dismiss", "route": "Refill round", "noroute": "No machine needs a refill in the next 2 days.",
        "machines": "Machines", "machine": "Machine", "status": "Status", "stock": "Stock", "empty_in": "Empty in",
        "days": "d", "avail": "Avail.", "daily": "Products dispensed per day", "hourly": "Sales by hour of day",
        "closed": "night: pharmacies closed", "data": "Show data", "date": "Date", "hour": "Hour", "sales": "Sales",
        "forecast": "Forecast", "actual": "Actual sales", "per_day": "per day", "method_model": "AI model",
        "method_rules": "starter rules (not enough data yet)", "back": "All machines", "last_seen": "Last signal",
        "good": "OK", "warning": "Attention", "serious": "Serious", "critical": "Critical", "offline": "Offline",
        "fault": "jammed", "updated": "Updated", "km": "km", "depot": "Depot", "review_note":
        "The AI only recommends: a person checks every alert and records the action taken.",
        "msg_offline": "No signal for {hours} h (power cut, GSM network or theft). Check on site.",
        "msg_probable_breakdown": "Only {observed} sale(s) in 24 h vs {expected} expected. Payment or dispensing may be broken.",
        "msg_dispense_failures": "{failures} failed dispenses in 24 h: mechanism jammed or empty. Customers to refund.",
        "msg_fraud_attempts": "{count} fake or replayed payment SMS blocked in 24 h.",
        "msg_refund_needed": "{n} payment(s) with a wrong amount: refund or deliver manually.",
        "msg_stock_out_soon": "{name}: {stock} left, empty in ~{days} day(s).",
    },
    "fr": {
        "title": "Réseau Axan", "availability": "Disponibilité des machines", "target": "objectif 95 %",
        "dispensed": "Produits distribués", "days30": "30 derniers jours", "offhours": "Achats la nuit ou le week-end",
        "offhours_sub": "quand les pharmacies sont fermées", "fraud": "Fraudes bloquées", "accuracy": "Erreur de prévision",
        "accuracy_sub": "unités/jour · modèle {m} vs naïf {n}", "alerts": "Alertes à vérifier", "noalerts": "Aucune alerte ouverte.",
        "validate": "Traité", "dismiss": "Ignorer", "route": "Tournée de réapprovisionnement",
        "noroute": "Aucune machine à recharger dans les 2 prochains jours.", "machines": "Machines", "machine": "Machine",
        "status": "État", "stock": "Stock", "empty_in": "Vide dans", "days": "j", "avail": "Dispo.",
        "daily": "Produits distribués par jour", "hourly": "Ventes par heure", "closed": "nuit : pharmacies fermées",
        "data": "Voir les données", "date": "Date", "hour": "Heure", "sales": "Ventes", "forecast": "Prévision",
        "actual": "Ventes réelles", "per_day": "par jour", "method_model": "modèle IA",
        "method_rules": "règles de démarrage (pas encore assez de données)", "back": "Toutes les machines",
        "last_seen": "Dernier signal", "good": "OK", "warning": "Attention", "serious": "Grave", "critical": "Critique",
        "offline": "Hors ligne", "fault": "bloqué", "updated": "Mis à jour", "km": "km", "depot": "Dépôt",
        "review_note": "L'IA ne fait que recommander : une personne vérifie chaque alerte et note l'action menée.",
        "msg_offline": "Aucun signal depuis {hours} h (coupure de courant, réseau GSM ou vol). Vérifier sur place.",
        "msg_probable_breakdown": "Seulement {observed} vente(s) en 24 h pour {expected} attendues. Paiement ou distribution peut-être en panne.",
        "msg_dispense_failures": "{failures} distributions échouées en 24 h : mécanisme bloqué ou vide. Clients à rembourser.",
        "msg_fraud_attempts": "{count} faux SMS de paiement ou rejeux bloqués en 24 h.",
        "msg_refund_needed": "{n} paiement(s) au mauvais montant : rembourser ou livrer manuellement.",
        "msg_stock_out_soon": "{name} : {stock} restant(s), vide dans ~{days} jour(s).",
    },
}
ICON = {"good": "✓", "warning": "▲", "serious": "◆", "critical": "✕", "offline": "○"}

CSS = """
:root{--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#8a8984;--line:#e4e3df;
--s1:#2a78d6;--s2:#eb6834;--brand:#e5007e;--good:#0ca30c;--warning:#c98500;--serious:#ec835a;--critical:#d03b3b;--band:#f0efec}
@media (prefers-color-scheme:dark){:root{--page:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--muted:#8f8e88;
--line:#2f2f2d;--s1:#3987e5;--s2:#d95926;--band:#262624}}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);font:15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
header{display:flex;align-items:center;gap:12px;padding:14px 16px;border-bottom:3px solid var(--brand);background:var(--surface)}
header b{font-size:20px;letter-spacing:.5px}header b span{color:var(--brand)}header small{color:var(--ink2);margin-left:auto}
header a{color:var(--ink2)}main{max-width:1180px;margin:0 auto;padding:16px}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:16px}
.tile,.card{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:14px}
.tile .v{font-size:28px;font-weight:650;font-variant-numeric:tabular-nums}.tile .l{color:var(--ink2);font-size:13px}
.tile .s{color:var(--muted);font-size:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}.grid>*,.card{min-width:0}
@media(max-width:760px){.grid{grid-template-columns:1fr}td.n{white-space:normal}}h2{font-size:16px;margin:0 0 10px}
table{width:100%;border-collapse:collapse;font-size:14px}th{text-align:left;color:var(--ink2);font-weight:500;border-bottom:1px solid var(--line);padding:6px 4px}
td{border-bottom:1px solid var(--line);padding:7px 4px;vertical-align:top}td.n{font-variant-numeric:tabular-nums;white-space:nowrap}
.badge{white-space:nowrap;font-weight:600}.good{color:var(--good)}.warning{color:var(--warning)}.serious{color:var(--serious)}
.critical{color:var(--critical)}.offline{color:var(--muted)}.bar{height:6px;background:var(--band);border-radius:3px;width:70px;display:inline-block;vertical-align:middle;margin-right:6px}
.bar i{display:block;height:6px;border-radius:3px;background:var(--s1)}.slot{margin-bottom:3px}
button{font:inherit;font-size:13px;border:1px solid var(--line);background:var(--page);color:var(--ink);border-radius:6px;padding:4px 10px;cursor:pointer}
button:hover{border-color:var(--ink2)}form{display:inline}.note{color:var(--muted);font-size:12px;margin-top:8px}
svg text{fill:var(--ink2);font-size:11px}svg .grid{stroke:var(--line)}svg .b{fill:var(--s1)}svg .b:hover{opacity:.75}
svg .fc{stroke:var(--s2);fill:none;stroke-width:2;stroke-dasharray:5 4}svg .fd{fill:var(--s2)}svg .band{fill:var(--band)}
.wrap{overflow-x:auto}details{margin-top:8px;color:var(--ink2);font-size:13px}a{color:var(--s1)}
.legend{display:flex;gap:14px;font-size:12px;color:var(--ink2);margin-bottom:6px}.legend i{display:inline-block;width:12px;height:3px;vertical-align:middle;margin-right:5px}
ol{margin:0;padding-left:20px}
"""


def esc(x) -> str:
    return html.escape(str(x))


def page(lang: str, body: str, title: str) -> str:
    t = T[lang]
    other = "fr" if lang == "en" else "en"
    return f"""<!doctype html><html lang="{lang}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>{CSS}</style></head>
<body><header><b>A<span>·</span>XAN</b><span>{esc(t['title'])}</span><small><a href="?lang={other}">{other.upper()}</a></small></header>
<main>{body}</main></body></html>"""


def alert_text(a: dict, lang: str) -> str:
    try:
        return T[lang]["msg_" + a["kind"]].format(**json.loads(a.get("data") or "{}"))
    except (KeyError, ValueError, IndexError):
        return a["message"]


def badge(status: str, lang: str) -> str:
    return f'<span class="badge {status}">{ICON.get(status, "")} {esc(T[lang].get(status, status))}</span>'


def nice_tick(x: float) -> int:
    """Smallest 'round' integer tick (1, 2, 3, 5 x 10^k) >= x."""
    k = 1
    while True:
        for m in (1, 2, 3, 5):
            if m * k >= x:
                return m * k
        k *= 10


def bar_chart(labels: list[str], values: list[float], title_fmt, height=170, shade=None, label_every=1, line=None) -> str:
    """Bar chart (+ optional dashed forecast line on the same y-axis).
    Hover a bar or point for its value (native SVG tooltip).
    line: list of (index, value, tooltip) drawn over the bars."""
    w, pad_l, pad_b, top = 640, 30, 22, 8
    n = max(1, len(values))
    vmax = max(values + [q for _, q, _ in (line or [])] + [1])
    ymax = 4 * nice_tick(vmax / 4)
    bw = (w - pad_l) / n
    plot_h = height - pad_b - top
    out = [f'<svg viewBox="0 0 {w} {height}" width="100%" role="img">']
    if shade:
        for i in shade:
            out.append(f'<rect class="band" x="{pad_l + i * bw:.1f}" y="{top}" width="{bw:.1f}" height="{plot_h}"/>')
    for k in range(0, 5):
        y = top + plot_h - plot_h * k / 4
        out.append(f'<line class="grid" x1="{pad_l}" x2="{w}" y1="{y:.1f}" y2="{y:.1f}"/><text x="{pad_l - 4}" y="{y + 4:.1f}" text-anchor="end">{int(ymax * k / 4)}</text>')
    for i, v in enumerate(values):
        h = plot_h * v / ymax
        x = pad_l + i * bw + 1
        bwid = max(1.0, bw - 2)
        r = min(4, bwid / 2, h)
        y = top + plot_h - h
        # rounded data end, square at the baseline
        out.append(f'<path class="b" d="M{x:.1f},{top + plot_h:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} H{x + bwid - r:.1f} '
                   f'Q{x + bwid:.1f},{y:.1f} {x + bwid:.1f},{y + r:.1f} V{top + plot_h:.1f} Z"><title>{esc(title_fmt(labels[i], v))}</title></path>')
        if i % label_every == 0:
            out.append(f'<text x="{x + bwid / 2:.1f}" y="{height - 6}" text-anchor="middle">{esc(labels[i])}</text>')
    if line:
        pts = [(pad_l + i * bw + bw / 2, top + plot_h - plot_h * q / ymax, tip) for i, q, tip in line]
        out.append('<polyline class="fc" points="' + " ".join(f"{x:.1f},{y:.1f}" for x, y, _ in pts) + '"/>')
        out += [f'<circle class="fd" cx="{x:.1f}" cy="{y:.1f}" r="4"><title>{esc(tip)}</title></circle>' for x, y, tip in pts]
    out.append("</svg>")
    return "".join(out)


def data_table(lang, head, rows) -> str:
    t = T[lang]
    body = "".join("<tr>" + "".join(f"<td class='n'>{esc(c)}</td>" for c in r) + "</tr>" for r in rows)
    return f"<details><summary>{t['data']}</summary><table><tr>{''.join(f'<th>{esc(h)}</th>' for h in head)}</tr>{body}</table></details>"


def overview(snap: dict, alerts: list[dict], lang: str) -> str:
    t, k = T[lang], snap["kpis"]
    pct = lambda x: "–" if x is None else f"{x * 100:.0f} %"
    acc = "–" if k["forecast_mae"] is None else f"{k['forecast_mae']:.1f}"
    tiles = f"""<div class="tiles">
<div class="tile"><div class="l">{t['availability']}</div><div class="v">{pct(k['availability_30d'])}</div><div class="s">{t['target']} · {t['days30']}</div></div>
<div class="tile"><div class="l">{t['dispensed']}</div><div class="v">{k['sales_30d']:,}</div><div class="s">{t['days30']}</div></div>
<div class="tile"><div class="l">{t['offhours']}</div><div class="v">{pct(k['off_hours_share'])}</div><div class="s">{t['offhours_sub']}</div></div>
<div class="tile"><div class="l">{t['fraud']}</div><div class="v">{k['fraud_blocked_30d']}</div><div class="s">{t['days30']}</div></div>
<div class="tile"><div class="l">{t['accuracy']}</div><div class="v">{acc}</div><div class="s">{t['accuracy_sub'].format(m=acc, n=k['naive_mae'] if k['naive_mae'] is not None else '–')}</div></div>
</div>""".replace(",", " ")

    names = {m["id"]: m["name"] for m in snap["machines"]}
    rows = "".join(
        f"<tr><td>{badge(a['severity'], lang)}</td><td><a href='/machine/{esc(a['machine_id'])}?lang={lang}'>{esc(names.get(a['machine_id'], a['machine_id']))}</a></td>"
        f"<td>{esc(alert_text(a, lang))}</td><td class='n'>{esc(a['created'][5:16].replace('T', ' '))}</td>"
        f"<td><form method='post' action='/alerts/{a['id']}/review?lang={lang}'><button name='action' value='validated'>{t['validate']}</button> "
        f"<button name='action' value='dismissed'>{t['dismiss']}</button></form></td></tr>" for a in alerts)
    alerts_html = f"<div class='card'><h2>{t['alerts']} ({len(alerts)})</h2>" + (
        f"<div class='wrap'><table>{rows}</table></div>" if alerts else f"<p>{t['noalerts']}</p>") + f"<div class='note'>{t['review_note']}</div></div>"

    r = snap["route"]
    route_html = f"<div class='card'><h2>{t['route']}</h2>" + (
        "<ol>" + f"<li>{t['depot']}</li>" + "".join(f"<li>{esc(names[s])}</li>" for s in r["stops"]) + f"<li>{t['depot']}</li></ol><div class='note'>≈ {r['km']} {t['km']}</div>"
        if r["stops"] else f"<p>{t['noroute']}</p>") + "</div>"

    mrows = ""
    for m in snap["machines"]:
        slots = ""
        for s in m["slots"]:
            frac = s["stock"] / s["capacity"] if s["capacity"] else 0
            dte = f"> 60 {t['days']}" if s["days_to_empty"] is None else f"{s['days_to_empty']} {t['days']}"
            fault = f" <span class='critical'>✕ {t['fault']}</span>" if s["fault"] else ""
            slots += f"<div class='slot'><span class='bar'><i style='width:{frac * 100:.0f}%'></i></span>{esc(s['name'])} {s['stock']}/{s['capacity']} · {t['empty_in']} {dte}{fault}</div>"
        mrows += (f"<tr><td><a href='/machine/{esc(m['id'])}?lang={lang}'>{esc(m['name'])}</a><br><small class='offline'>{esc(m['id'])}</small></td>"
                  f"<td>{badge(m['status'], lang)}</td><td>{slots}</td><td class='n'>{m['availability_30d'] * 100:.0f} %</td></tr>")
    machines_html = f"<div class='card'><h2>{t['machines']}</h2><div class='wrap'><table><tr><th>{t['machine']}</th><th>{t['status']}</th><th>{t['stock']}</th><th>{t['avail']}</th></tr>{mrows}</table></div></div>"

    days = list(snap["daily_sales"].items())
    daily = bar_chart([d[8:10] for d, _ in days], [v for _, v in days], lambda l, v: f"{l}: {int(v)}", label_every=3)
    hours = snap["hourly_sales"]
    hourly = bar_chart([f"{h}h" for h in range(24)], hours, lambda l, v: f"{l}: {int(v)}", shade=list(range(0, 7)) + list(range(20, 24)), label_every=2)
    charts = f"""<div class="grid">
<div class="card"><h2>{t['daily']}</h2>{daily}{data_table(lang, [t['date'], t['sales']], days)}</div>
<div class="card"><h2>{t['hourly']}</h2><div class="legend"><span><i style="background:var(--band);height:10px"></i>{t['closed']}</span></div>{hourly}
{data_table(lang, [t['hour'], t['sales']], [(f'{h}h', v) for h, v in enumerate(hours)])}</div></div>"""

    return page(lang, tiles + f"<div class='grid'>{alerts_html}{route_html}</div>" + charts + machines_html +
                f"<p class='note'>{t['updated']} {esc(snap['generated'].replace('T', ' '))} UTC</p>", t["title"])


def machine_page(m: dict, histories: dict[int, dict], forecasts: dict[int, list], lang: str) -> str:
    t = T[lang]
    cards = ""
    for s in m["slots"]:
        hist = histories[s["index"]]
        fc = forecasts[s["index"]]
        labels = [d[8:10] for d in hist] + [d.isoformat()[8:10] for d, _ in fc]
        values = list(hist.values()) + [0] * len(fc)
        line = [(len(hist) + j, q, f"{d.isoformat()}: {q:.1f}") for j, (d, q) in enumerate(fc)]
        svg = bar_chart(labels, values, lambda l, v: f"{l}: {int(v)}", label_every=4, line=line)
        method = t["method_model"] if s["method"] == "model" else t["method_rules"]
        bt = s["backtest"]
        bt_txt = f" · MAE {bt['mae_model']} vs {bt['mae_naive']}" if bt else ""
        dte = f"> 60 {t['days']}" if s["days_to_empty"] is None else f"{s['days_to_empty']} {t['days']}"
        cards += f"""<div class="card"><h2>{esc(s['name'])} — {s['stock']}/{s['capacity']} · {t['empty_in']} {dte}</h2>
<div class="legend"><span><i style="background:var(--s1)"></i>{t['actual']}</span><span><i style="background:var(--s2)"></i>{t['forecast']} ({s['per_day']} {t['per_day']}, {method}{bt_txt})</span></div>
{svg}{data_table(lang, [t['date'], t['actual'], t['forecast']], [(d, v, '') for d, v in hist.items()] + [(d.isoformat(), '', f'{q:.1f}') for d, q in fc])}</div>"""
    head = f"<p><a href='/?lang={lang}'>← {t['back']}</a></p><h2>{esc(m['name'])} {badge(m['status'], lang)}</h2><p class='note'>{esc(m['id'])} · {t['last_seen']} {esc((m['last_seen'] or '–').replace('T', ' '))}</p>"
    return page(lang, head + f"<div class='grid'>{cards}</div>", m["name"])
