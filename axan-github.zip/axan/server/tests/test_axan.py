# SPDX-License-Identifier: Apache-2.0
import os
import sys
from datetime import date, datetime, timedelta, timezone

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "simulator"))

from axan_server import db  # noqa: E402
from axan_server.ai import anomalies, forecast, routing  # noqa: E402


# ---------------------------------------------------------------- forecast

def weekly_history(days=56, end=date(2026, 11, 7)):
    # 2/day on weekdays, 8/day on Saturdays
    return {end - timedelta(days=i): (8 if (end - timedelta(days=i)).weekday() == 5 else 2) for i in range(1, days + 1)}


def test_cold_start_uses_rules():
    m = forecast.fit({date(2026, 11, 6): 3}, date(2026, 11, 7))
    assert m.method == "rules" and m.predict(date(2026, 11, 8)) == 3
    assert forecast.fit({}, date(2026, 11, 7)).level == forecast.DEFAULT_RATE


def test_model_learns_weekday_pattern():
    end = date(2026, 11, 7)
    m = forecast.fit(weekly_history(end=end), end)
    sat = next(end + timedelta(days=i) for i in range(7) if (end + timedelta(days=i)).weekday() == 5)
    tue = next(end + timedelta(days=i) for i in range(7) if (end + timedelta(days=i)).weekday() == 1)
    assert m.method == "model"
    assert m.predict(sat) > 2.5 * m.predict(tue)


def test_backtest_beats_naive_on_seasonal_data():
    end = date(2026, 11, 7)
    bt = forecast.backtest(weekly_history(end=end), end)
    assert bt is not None and bt.mae_model < bt.mae_naive


def test_days_until_empty():
    m = forecast.Model(method="rules", level=5)
    assert forecast.days_until_empty(m, 12, date(2026, 11, 7)) == 2.4
    assert forecast.days_until_empty(m, 0, date(2026, 11, 7)) == 0


# ---------------------------------------------------------------- anomalies

NOW = datetime(2026, 11, 7, 12, 0)


def ev(hours_ago, typ="sale"):
    return {"t": NOW - timedelta(hours=hours_ago), "type": typ}


def steady(days=14, per_day=10):
    out = [ev(h * 24 / per_day) for h in range(per_day * days)]
    out += [ev(h / 4, "heartbeat") for h in range(0, 4 * 24 * days)]
    return out


def test_poisson_cdf():
    assert abs(anomalies.poisson_cdf(0, 2) - 0.1353) < 1e-3
    assert anomalies.poisson_cdf(100, 3) == pytest.approx(1.0)


def test_silent_breakdown_detected():
    events = [e for e in steady() if not (e["type"] == "sale" and NOW - e["t"] < timedelta(hours=24))]
    kinds = {f.kind for f in anomalies.detect("M", events, NOW, has_stock=True)}
    assert "probable_breakdown" in kinds


def test_normal_machine_has_no_alert():
    assert anomalies.detect("M", steady(), NOW, has_stock=True) == []


def test_offline_and_fraud():
    events = [ev(5, "heartbeat")] + [ev(6 + i, "sms_rejected") for i in range(3)]
    kinds = {f.kind for f in anomalies.detect("M", events, NOW, has_stock=True)}
    assert {"offline", "fraud_attempts"} <= kinds


# ---------------------------------------------------------------- routing

def test_route_is_round_trip_and_short():
    depot = (12.37, -1.52)
    stops = {"A": (12.40, -1.52), "B": (12.30, -1.52), "C": (12.41, -1.52)}
    order, km = routing.plan_route(depot, stops)
    assert sorted(order) == ["A", "B", "C"]
    assert order in (["A", "C", "B"], ["B", "C", "A"])
    assert km > 0


# ---------------------------------------------------------------- API + dashboard

@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("AXAN_DB", str(tmp_path / "t.db"))
    from fastapi.testclient import TestClient
    from axan_server import app as appmod
    appmod._conn = None
    c = db.connect()
    db.add_machine(c, "M1", "Test", "university", 12.37, -1.50, api_key="k1")
    return TestClient(appmod.app)


def test_api_rejects_bad_key(client):
    r = client.post("/api/v1/events", json={"machine_id": "M1", "events": []}, headers={"X-API-Key": "nope"})
    assert r.status_code == 401


def test_api_idempotent_and_never_stores_phone_numbers(client):
    batch = {"machine_id": "M1", "events": [
        {"seq": 1, "ts": "2026-11-07T10:00:00", "type": "sale", "slot": 0, "amount": 300, "ref": "R1", "payer": "70123456", "stock": [49, 40, 40]},
        {"seq": 2, "ts": "2026-11-07T10:05:00", "type": "sale", "slot": 0, "amount": 300, "ref": "R2", "payer": "a1b2c3d4e5f60718", "stock": [48, 40, 40]},
        {"seq": 3, "ts": "2026-11-07T10:06:00", "type": "drop_table", "slot": 0},
    ]}
    h = {"X-API-Key": "k1"}
    assert client.post("/api/v1/events", json=batch, headers=h).json()["stored"] == 2
    assert client.post("/api/v1/events", json=batch, headers=h).json()["stored"] == 0  # retry after GPRS drop
    from axan_server import app as appmod
    payers = [r["payer"] for r in appmod.conn().execute("SELECT payer FROM events ORDER BY seq")]
    assert payers == [None, "a1b2c3d4e5f60718"]  # raw phone number dropped, hash kept


def test_dashboard_and_alert_review(client):
    import simulate
    from axan_server import app as appmod
    data = simulate.simulate(30, datetime.now(timezone.utc).replace(tzinfo=None, second=0, microsecond=0))
    c = appmod.conn()
    for mid, name, site, lat, lon, _ in simulate.SITES:
        db.add_machine(c, mid, name, site, lat, lon, api_key="x")
        db.ingest(c, mid, data[mid])
    r = client.get("/?lang=fr")
    assert r.status_code == 200 and "Alertes à vérifier" in r.text and "Tournée" in r.text
    alert = c.execute("SELECT id FROM alerts WHERE status='open' LIMIT 1").fetchone()
    assert alert
    r = client.post(f"/alerts/{alert['id']}/review", data={"action": "validated"}, follow_redirects=False)
    assert r.status_code == 303
    assert c.execute("SELECT status FROM alerts WHERE id=?", (alert["id"],)).fetchone()["status"] == "validated"
    assert client.get("/machine/AXN-OUA-001?lang=en").status_code == 200
