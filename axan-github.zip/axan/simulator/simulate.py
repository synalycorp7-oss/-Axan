"""Generates realistic demo data for a 10-machine pilot in Ouagadougou
(90 days: sales, heartbeats, refills, plus injected incidents) so the AI and the
dashboard can be demonstrated before the real pilot. ALL DATA IS SYNTHETIC.

  python simulator/simulate.py --db axan.db              # write directly to SQLite
  python simulator/simulate.py --url http://localhost:8000  # push through the real API
"""
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import urllib.request
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
from axan_server import db  # noqa: E402

# Approximate locations, for demonstration only.
SITES = [
    ("AXN-OUA-001", "Université Joseph Ki-Zerbo", "university", 12.3786, -1.4967, 7.0),
    ("AXN-OUA-002", "Cité universitaire de Kossodo", "university", 12.4060, -1.4790, 6.0),
    ("AXN-OUA-003", "Gare routière Ouaga-Inter", "bus_station", 12.3355, -1.5560, 5.0),
    ("AXN-OUA-004", "Université Thomas Sankara", "university", 12.2900, -1.4000, 4.0),
    ("AXN-OUA-005", "Station-service Ouaga 2000", "fuel_station", 12.3200, -1.4950, 3.5),
    ("AXN-OUA-006", "Maquis, Gounghin", "bar", 12.3650, -1.5450, 6.5),
    ("AXN-OUA-007", "Hôtel, Koulouba", "hotel", 12.3750, -1.5250, 3.0),
    ("AXN-OUA-008", "Marché Rood Woko", "market", 12.3680, -1.5270, 4.5),
    ("AXN-OUA-009", "Patte d'Oie", "neighbourhood", 12.3400, -1.5100, 3.0),
    ("AXN-OUA-010", "Gare ferroviaire", "train_station", 12.3730, -1.5130, 2.5),
]
HOUR = [3, 2, 1.5, 1, .5, .3, .4, .6, .7, .8, .9, 1, 1.1, 1, 1, 1.1, 1.3, 1.6, 2.2, 3, 3.6, 3.8, 3.6, 3.2]
WEEKDAY = [0.85, 0.85, 0.9, 0.95, 1.25, 1.5, 1.1]
MIX = [0.6, 0.1, 0.3]             # condoms, female condom, pads
PRICES = [300, 500, 500]
CAPACITY = [50, 40, 40]


def payday(d):
    return d.day >= 25 or d.day <= 3


def simulate(days: int, now: datetime, seed: int = 7):
    rng = random.Random(seed)
    start = (now - timedelta(days=days)).replace(minute=0, second=0, microsecond=0)
    hsum = sum(HOUR)
    per_machine = {}
    for mid, name, site, lat, lon, base in SITES:
        ev, seq = [], 0
        stock = CAPACITY[:]
        refill_at = None

        def add(t, typ, **kw):
            nonlocal seq
            seq += 1
            ev.append({"seq": seq, "ts": t.isoformat(timespec="seconds"), "type": typ, "stock": stock[:], **kw})

        t = start
        while t < now:
            hours_ago = (now - t).total_seconds() / 3600
            offline = mid == "AXN-OUA-003" and hours_ago < 5            # incident: GSM/power down
            silent = mid == "AXN-OUA-002" and hours_ago < 26             # incident: payment SMS no longer arrive
            jammed = mid == "AXN-OUA-006" and hours_ago < 30             # incident: slot 1 mechanism jammed
            lam = base * WEEKDAY[t.weekday()] * (1.3 if payday(t) else 1) * HOUR[t.hour] / hsum / 4  # per 15 min
            if not offline:
                for _ in range(_poisson(rng, lam)):
                    slot = rng.choices(range(3), MIX)[0]
                    ts = t + timedelta(seconds=rng.randint(0, 899))
                    ref = f"PP{ts:%y%m%d.%H%M}.{rng.randint(10000, 99999)}"
                    payer = f"{rng.getrandbits(64):016x}"
                    if silent:
                        continue
                    if jammed and slot == 0:
                        add(ts, "dispense_failed", slot=0, amount=PRICES[0], ref=ref, payer=payer, detail="no_drop_detected")
                    elif stock[slot] > 0:
                        stock[slot] -= 1
                        add(ts, "sale", slot=slot, amount=PRICES[slot], ref=ref, payer=payer)
                    else:
                        add(ts, "dispense_failed", slot=slot, amount=PRICES[slot], ref=ref, payer=payer, detail="empty")
                if rng.random() < 0.0005:
                    add(t, "sms_rejected", slot=-1, amount=PRICES[0], detail="untrusted_sender")
                add(t, "heartbeat", slot=-1, amount=rng.randint(12, 24))
            # Field team: refill 0-36 h after a slot gets low (realistic delays -> some stock-outs).
            if refill_at is None and min(s / c for s, c in zip(stock, CAPACITY)) <= 0.16:
                refill_at = t + timedelta(hours=rng.uniform(2, 36))
            if refill_at and t >= refill_at and 8 <= t.hour <= 17 and not offline:
                for i in range(3):
                    stock[i] = CAPACITY[i]
                    add(t, "refill", slot=i, amount=0)
                refill_at = None
            t += timedelta(minutes=15)

        if mid == "AXN-OUA-008":  # incident: fake payment SMS campaign
            for k in range(4):
                add(now - timedelta(hours=3 + k * 2), "sms_rejected", slot=-1, amount=300, detail="untrusted_sender")
            add(now - timedelta(hours=1), "replay_blocked", slot=-1, amount=300, ref="PP261106.2210.55555", detail="replay")
        if mid == "AXN-OUA-005":
            add(now - timedelta(hours=4), "amount_mismatch", slot=-1, amount=250, ref="PP261107.0110.42424", detail="refund_needed")
        if mid == "AXN-OUA-009":  # one slot running low, refill not yet planned
            stock[0] = 5
            add(now - timedelta(minutes=10), "heartbeat", slot=-1, amount=18)
        ev.sort(key=lambda e: e["ts"])
        per_machine[mid] = ev
    return per_machine


def _poisson(rng, lam):
    L, k, p = pow(2.718281828, -lam), 0, 1.0
    while True:
        p *= rng.random()
        if p <= L:
            return k
        k += 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="axan.db")
    ap.add_argument("--url", help="push through a running server instead of writing SQLite")
    ap.add_argument("--days", type=int, default=90)
    args = ap.parse_args()
    now = datetime.now(timezone.utc).replace(tzinfo=None, second=0, microsecond=0)
    data = simulate(args.days, now)
    conn = db.connect(args.db)
    keys = {}
    for mid, name, site, lat, lon, _ in SITES:
        keys[mid] = db.add_machine(conn, mid, name, site, lat, lon, api_key=f"demo-{mid}")
    total = 0
    for mid, events in data.items():
        if args.url:
            for i in range(0, len(events), 200):
                body = json.dumps({"machine_id": mid, "events": events[i:i + 200]}).encode()
                req = urllib.request.Request(args.url.rstrip("/") + "/api/v1/events", body,
                                             {"Content-Type": "application/json", "X-API-Key": keys[mid]})
                total += json.load(urllib.request.urlopen(req))["stored"]
        else:
            total += db.ingest(conn, mid, events)
    sales = sum(1 for ev in data.values() for e in ev if e["type"] == "sale")
    print(f"{len(SITES)} machines, {total} events stored ({sales} sales) over {args.days} days. Demo API keys: demo-<machine id>")


if __name__ == "__main__":
    main()
