# Axan (français)

**Axan** (« acheter » en dioula) est un distributeur automatique open source payable par
**mobile money** (Orange Money, Moov Money). Il offre aux jeunes femmes, aux filles et aux jeunes
un accès **anonyme 24h/24** aux préservatifs, préservatifs féminins et serviettes hygiéniques.
Son **IA prédit les ruptures de stock, détecte les pannes et bloque les fraudes au paiement**,
même là où internet est faible. Développé au Burkina Faso par **Synaly Corporation SAS**, sous licence Apache 2.0.

## En bref

- **Paiement :** l'utilisateur choisit son produit, paie par mobile money, la machine lit le SMS
  de confirmation de l'opérateur et délivre le produit. Aucun smartphone ni internet n'est nécessaire.
- **Sécurité du paiement :** seuls les SMS des expéditeurs officiels sont acceptés, une référence
  de transaction ne peut servir qu'une fois, et le montant doit correspondre au produit.
- **Mode hors ligne :** les ventes sont enregistrées dans la machine et envoyées au serveur dès que le réseau revient.
- **IA :** prévision de la demande par machine et par produit, détection des pannes silencieuses
  et des fraudes, tournée de réapprovisionnement optimisée.
- **Supervision humaine :** chaque alerte est vérifiée par une personne sur le tableau de bord.
- **Vie privée :** aucun numéro de téléphone n'est stocké, ils sont hachés dans la machine.

## Démarrer

```bash
cd server
pip install -r requirements.txt
python ../simulator/simulate.py --db axan.db
AXAN_DB=axan.db uvicorn axan_server.app:app --port 8000
# ouvrir http://localhost:8000/?lang=fr
```

Firmware : ouvrir `firmware/axan/axan.ino` dans l'IDE Arduino (carte ESP32, bibliothèque ESP32Servo),
puis adapter `config.h`.

Commandes SMS du gestionnaire : `RECHARGE <produit> <quantité>`, `ETAT`, `TEST <produit>`.

Tests : `make -C firmware test` et `python -m pytest -q server/tests`.

Documentation complète en anglais : [README.md](README.md).
