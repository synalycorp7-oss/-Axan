# Axan — discreet, always-available access to contraception and menstrual products

**Axan** ("to buy" in Dioula) is an open-source vending machine paid by **mobile money**
(Orange Money, Moov Money) that gives young women, girls and young people **24/7 anonymous
access** to condoms, female condoms and sanitary pads, with **AI that predicts stock-outs,
detects breakdowns and blocks payment fraud**. It works where internet is weak or absent.

Developed in Burkina Faso by **Synaly Corporation SAS**. Licensed under **Apache 2.0**.

![Dashboard](docs/img/dashboard.png)

---

## Why

- Many young people do not buy condoms or pads because they fear being seen or judged at the counter.
- Pharmacies are closed at night and at weekends, when the need is often highest.
  The dashboard measures exactly this: the share of purchases made when pharmacies are closed.
- A vending machine removes the human barrier, but only if it **is never empty and never broken**.
  Stock-outs are one of the main barriers to family planning and menstrual health.

## How it works

```mermaid
flowchart LR
  U[User] -- "1. selects product (button)" --> M[Axan machine<br/>ESP32 + SIM800L]
  U -- "2. pays by mobile money<br/>(QR code / USSD, any phone)" --> OP[Operator]
  OP -- "3. confirmation SMS" --> M
  M -- "4. checks SMS, dispenses,<br/>IR sensor confirms" --> U
  M -- "5. events (offline queue,<br/>GPRS when available)" --> S[Axan server]
  S -- "AI: forecasts, anomalies,<br/>refill route" --> D[Dashboard]
  S -- "SMS alerts" --> F[Field manager]
  F -- "validates alerts,<br/>refills, refunds" --> M
```

- **No smartphone, no cash, no internet needed for the user**: payment is validated by the
  machine itself from the operator's SMS, so the machine keeps selling during network or server outages.
- Every event is stored in flash and uploaded when GPRS is available. Nothing is lost.

## What the AI does

| Function | How | Why it matters |
|---|---|---|
| **Demand forecasting** (`server/axan_server/ai/forecast.py`) | Per machine and product: exponential smoothing x learned weekday and payday effects, with shrinkage for small data; starter rules when history < 14 days | Predicts *when* each slot will be empty so it is refilled before a stock-out |
| **Accuracy check** | Weekly backtest vs a naive baseline, shown on the dashboard | Accuracy is measured, not assumed |
| **Silent breakdown detection** (`ai/anomalies.py`) | Poisson test: sales in the last 24 h vs expected (p < 0.01) while stocked and online | Catches failures nobody reports (payment SMS not arriving, jammed mechanism) |
| **Fraud detection** (firmware + server) | Rejects "payment" SMS from non-operator numbers, blocks replayed transaction references, flags campaigns of attempts | Protects the service's revenue and sustainability |
| **Refill routing** (`ai/routing.py`) | Nearest neighbour + 2-opt over machines that need a visit | Fewer kilometres, lower cost, affordable prices |

The models are small, explainable and run on any CPU (no GPU, no cloud AI service, no
external ML dependency), which keeps the system cheap to host locally.

## Responsible AI, safety and privacy

- **No personal data.** The machine hashes the payer number (salted SHA-256) before anything
  leaves it; the server rejects anything that is not a hash. Analysis uses only sales counts,
  time, place and machine status. No names, no accounts, no tracking of individuals.
- **Human oversight.** The AI never acts on its own: every alert is reviewed on the dashboard
  by a person who marks it *Done* or *Dismiss* (logged with name and time). Refunds and
  refills are human decisions.
- **Refunds.** If a paid product is not dispensed (jam, empty slot, wrong amount), the field
  manager immediately receives an SMS with the transaction reference to refund the customer.
- **Inclusion.** Any basic phone works; visual instructions; the dashboard is bilingual
  (English / French) and works on low-end phones without JavaScript frameworks or CDNs.
- **Open data for health systems.** `/api/v1/open-data/daily` gives anonymous, aggregated
  demand per machine and day so family-planning programmes can see where needs are highest.

See [docs/RESPONSIBLE_AI.md](docs/RESPONSIBLE_AI.md).

## Repository

```
firmware/axan/          ESP32 firmware (Arduino): SMS payment, dispensing, offline queue, sync
  axan.ino              main program
  config.h              per-machine configuration (pins, prices, operator sender IDs, server)
  sms_parser.{h,cpp}    pure C++ payment parser + anti-replay, unit-tested on PC
firmware/test/          PC tests: parser tests + full firmware simulation with a fake SIM800L
server/axan_server/     FastAPI + SQLite server, AI modules, dashboard
simulator/simulate.py   synthetic 10-machine pilot (90 days) with injected incidents, for demos
docs/                   hardware, architecture, responsible AI
```

## Quick start (server + demo data)

```bash
cd server
pip install -r requirements.txt
python ../simulator/simulate.py --db axan.db      # synthetic demo data
AXAN_DB=axan.db uvicorn axan_server.app:app --port 8000
# open http://localhost:8000  (add ?lang=fr for French)
```

Register a real machine and get its API key:

```bash
AXAN_DB=axan.db python -m axan_server.manage add-machine AXN-OUA-001 "Université Joseph Ki-Zerbo" --lat 12.3786 --lon -1.4967 --site university
```

Production settings: `AXAN_ADMIN_PASSWORD` (dashboard login), `AXAN_SMS_WEBHOOK` and
`AXAN_MANAGER_PHONE` (alert SMS through any SMS gateway), `AXAN_DEPOT_LAT/LON` (refill depot).

## Firmware

1. Arduino IDE with the **ESP32** board package and the **ESP32Servo** library.
2. Edit `firmware/axan/config.h`: machine ID, API key, salt, APN, server URL, manager number,
   prices, pins, and the **official sender IDs** of the operators' payment SMS.
3. Flash `firmware/axan/axan.ino` to the ESP32.

Manager SMS commands (from `MANAGER_NUMBER` only): `RECHARGE <product> <qty>`, `ETAT`, `TEST <product>`.

Hardware and wiring: [docs/HARDWARE.md](docs/HARDWARE.md).

## Tests

```bash
make -C firmware test                 # SMS parser + full firmware simulation on PC
pip install -r server/requirements-dev.txt && python -m pytest -q server/tests
```

The firmware simulation runs `axan.ino` against a fake SIM800L and checks: fake SMS rejected,
genuine payment dispensed, replay blocked, button selection, jam -> refund alert,
wrong amount, manager refill, offline queue then upload, and that phone numbers are never logged.

## Project status

- **Prototype:** working machine (QR code, mobile money payment, automatic dispensing) — see the demo video.
- **This repository:** reference software for the 10-machine pilot. The firmware is tested
  on PC simulation; field validation on the pilot hardware is the next step.
- **Before deployment:** add real Orange Money / Moov Money confirmation SMS (number masked)
  to `firmware/test/test_sms_parser.cpp` and adjust `PAYMENT_KEYWORDS` / `TRUSTED_SENDERS`.
- The demo data and site coordinates in `simulator/` are **synthetic**.

## Roadmap (12 months)

1. Build and install 10 machines in Ouagadougou (universities, stations, markets); obtain authorizations.
2. Pilot: target > 95% machine availability; collect real data and retrain the forecasting model.
3. Add sanitary pads and female condoms on every machine; partner with health programmes for subsidised supply.
4. Prepare expansion to Côte d'Ivoire and Senegal (Orange Money, Moov, MTN, Wave via an aggregator).

## Contributing

Issues and pull requests are welcome. Please keep the privacy rules above: no personal data,
human review of every automated recommendation.

## License

Apache License 2.0 — see [LICENSE](LICENSE). © 2026 Synaly Corporation SAS.
Contact: synalycorp7@gmail.com
