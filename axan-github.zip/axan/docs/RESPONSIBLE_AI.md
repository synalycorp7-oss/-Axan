# Responsible AI, privacy and safety

Axan serves people who need discretion. Anonymity is the condition for the service to be used,
so privacy is enforced by design, in code, not only by policy.

## Data we collect

| Data | Where | Kept? |
|---|---|---|
| Sale: time, machine, product slot, amount, operator transaction reference | machine -> server | yes |
| Machine status: stock per slot, GSM signal, failures | machine -> server | yes |
| Payer phone number | machine RAM only | **never stored or sent in clear**: salted SHA-256, 16 hex chars |
| Names, age, gender, location of users | — | **never collected** |

- The hash only lets us count repeated fraud attempts; it cannot be reversed without the
  per-machine secret salt, which never leaves the machine.
- The server refuses any payer value that is not a 16-character hash (`db._is_hash`), so a
  misconfigured machine cannot leak phone numbers into the database.
- The only place a phone number appears is the **refund SMS sent to the field manager** when a
  paid product was not delivered: it is needed to give the money back and is not stored by the server.

## Human oversight

- The AI produces **recommendations** (refill soon, probable breakdown, fraud campaign, refund needed).
- Every alert appears on the dashboard and must be marked **Done** or **Dismiss** by a person;
  the reviewer and time are recorded. Nothing is blocked or changed automatically by the server.
- On the machine, automatic actions are limited to protecting the customer: a product is only
  dispensed for a valid, unused, correctly-priced payment; otherwise the manager is alerted.

## Accuracy and reliability

- Forecasts are backtested every time the dashboard is computed (last 7 days held out) and compared
  with a naive baseline; both errors are displayed. If the model is not better, we see it.
- With fewer than 14 days of data, simple transparent rules are used instead of the model.
- Breakdown alerts use a statistical test (Poisson, p < 0.01) and are only raised for machines
  that normally sell enough for the test to be meaningful, to avoid false alarms.
- The machine works fully offline: payment validation and dispensing never depend on the server.

## Fairness and inclusion

- Works with any basic phone (QR code or USSD); no smartphone, app, account or ID required.
- Bilingual dashboard (English/French), lightweight HTML for low-end phones and weak networks.
- Products for women and girls (sanitary pads, female condoms) alongside condoms.
- Sites are chosen with health partners; machines selling condoms are not placed in places
  intended for minors.

## Known limitations

- Operator SMS formats change: real SMS samples must be added to the tests before each deployment.
- SMS-based payment confirmation depends on operator SMS delivery; a payment-aggregator webhook
  integration is planned for scale-up.
- Demo data in `simulator/` is synthetic and must not be presented as field results.
