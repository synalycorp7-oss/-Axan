# Hardware

## Bill of materials (per machine, indicative)

| Part | Notes |
|---|---|
| ESP32 DevKit (ESP-WROOM-32) | main controller |
| SIM800L GSM/GPRS module + antenna + SIM card | receives payment SMS, uploads data (SIM7600 for 4G areas) |
| 3 x servo motors (MG996R or SG90 depending on mechanism) | one per product slot |
| IR break-beam sensor (or IR obstacle sensor) at the output tray | confirms the product dropped |
| 3 x push buttons | product selection ("Select before paying") |
| LED + buzzer | user feedback |
| 5 V / 3 A supply + 4.2 V supply for SIM800L (or LM2596 buck) | SIM800L needs up to 2 A peaks: add a 1000 µF capacitor |
| 12 V battery + charge controller, optional 20-30 W solar panel | power cuts |
| Enclosure (PVC/acrylic or sheet metal), lock, ventilation | protect latex from heat > 40 °C |

## Default wiring (`firmware/axan/config.h`)

| Signal | ESP32 pin |
|---|---|
| SIM800L TX -> ESP32 RX2 | GPIO 16 |
| SIM800L RX <- ESP32 TX2 (3.3 V logic, direct) | GPIO 17 |
| Servo product 1 / 2 / 3 | GPIO 13 / 14 / 27 |
| Button product 1 / 2 / 3 (to GND, internal pull-up) | GPIO 32 / 33 / 25 |
| IR drop sensor output | GPIO 34 (active LOW) |
| LED | GPIO 2 |
| Buzzer | GPIO 26 |

Servos must be powered from the 5 V rail, not from the ESP32. Common ground for everything.

## Mechanism

Each slot is a vertical gravity column. The servo pushes the lowest item through a slot into
the output tray, then returns to rest. If the IR beam does not see the item within 3 s, the
firmware retries once, then marks the slot as jammed and alerts the manager for a refund.
