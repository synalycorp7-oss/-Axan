// Host unit tests for the SMS parser:  make -C firmware test
// NOTE: the SMS bodies below are illustrative formats. Add real operator SMS
// (with the payer number masked) to this file before deploying.
// SPDX-License-Identifier: Apache-2.0
#include <stdio.h>
#include <string.h>
#include "sms_parser.h"

using namespace axan;

static int failures = 0;
#define CHECK(cond) do { if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } } while (0)

static const char* const TRUSTED[] = {"OrangeMoney", "MoovMoney", "Orange Money", "MOOV AFRICA"};
static const char* const KEYWORDS[] = {"recu", "reçu", "received", "transfert de", "depot"};

static Verdict parse(const char* body, Payment* p) { return parsePayment(body, KEYWORDS, 5, p); }

int main() {
  Payment p;

  // 1. Typical incoming transfer.
  CHECK(parse("Vous avez recu 300 FCFA du 70123456. Ref: PP231103.1207.A12345. Nouveau solde: 12 500 FCFA.", &p) == PAY_OK);
  CHECK(p.amount == 300);
  CHECK(strcmp(p.ref, "PP231103.1207.A12345") == 0);
  CHECK(strcmp(p.payer, "70123456") == 0);

  // 2. Thousand separator, accented keyword, "Trans ID".
  CHECK(parse("Transfert reçu de 22676543210 montant 1 000 F CFA. Trans ID: MP2311031234567", &p) == PAY_OK);
  CHECK(p.amount == 1000);
  CHECK(strcmp(p.ref, "MP2311031234567") == 0);
  CHECK(strcmp(p.payer, "22676543210") == 0);

  // 2b. "Transfert" must not be mistaken for "Trans" (payer number is not a reference).
  CHECK(parse("Transfert recu de 22676000000 montant 500 F CFA. Trans ID: MP2311071239999", &p) == PAY_OK);
  CHECK(strcmp(p.ref, "MP2311071239999") == 0);
  CHECK(strcmp(p.payer, "22676000000") == 0);
  CHECK(parse("Transfert recu de 22676000000 montant 500 F CFA", &p) == REJECT_NO_REF);
  CHECK(parse("Depot de 1.500 FCFA. Ref No: 7788AB99", &p) == PAY_OK);
  CHECK(p.amount == 1500 && strcmp(p.ref, "7788AB99") == 0);

  // 3. Decimals and XOF.
  CHECK(parse("You have received 500.00 XOF from 65432109. Transaction ID 9A8B7C6D", &p) == PAY_OK);
  CHECK(p.amount == 500);
  CHECK(strcmp(p.ref, "9A8B7C6D") == 0);

  // 4. Not a payment (promo / balance).
  CHECK(parse("Profitez de 1 Go a 500 FCFA ce weekend!", &p) == REJECT_NOT_PAYMENT);

  // 5. Payment-like SMS without reference.
  CHECK(parse("Vous avez recu 300 FCFA", &p) == REJECT_NO_REF);

  // 6. No amount.
  CHECK(parse("Vous avez recu un transfert. Ref: AB1234", &p) == REJECT_NO_AMOUNT);

  // 7. Trusted senders: official IDs only, ordinary numbers rejected.
  CHECK(isTrustedSender("OrangeMoney", TRUSTED, 4));
  CHECK(isTrustedSender("orangemoney", TRUSTED, 4));
  CHECK(!isTrustedSender("+22670123456", TRUSTED, 4));
  CHECK(!isTrustedSender("OrangeMoney2", TRUSTED, 4));
  CHECK(!isTrustedSender("", TRUSTED, 4));

  // 8. Replay guard.
  ReplayGuard g;
  CHECK(!g.seen("PP231103.1207.A12345"));
  g.remember("PP231103.1207.A12345");
  CHECK(g.seen("PP231103.1207.A12345"));
  CHECK(g.seen("pp231103.1207.a12345"));  // case-insensitive
  for (int i = 0; i < ReplayGuard::CAPACITY; ++i) { char r[16]; snprintf(r, sizeof r, "R%05d", i); g.remember(r); }
  CHECK(!g.seen("PP231103.1207.A12345"));  // evicted after CAPACITY new refs
  ReplayGuard g2; g2.load(g.data(), ReplayGuard::CAPACITY, g.head());
  CHECK(g2.seen("R00010"));

  // 9. Product resolution.
  const long prices[] = {300, 500, 500};
  CHECK(resolveProduct(300, -1, prices, 3) == 0);
  CHECK(resolveProduct(500, -1, prices, 3) == 1);   // ambiguous price -> first match
  CHECK(resolveProduct(500, 2, prices, 3) == 2);    // button selection wins
  CHECK(resolveProduct(300, 2, prices, 3) == -1);   // underpaid
  CHECK(resolveProduct(250, -1, prices, 3) == -1);

  if (failures == 0) printf("All SMS parser tests passed.\n");
  return failures == 0 ? 0 : 1;
}
