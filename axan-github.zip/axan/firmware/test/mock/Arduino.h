// Minimal Arduino/ESP32 mock so axan.ino can be compiled and exercised on a PC.
// Only what the firmware uses is implemented. Not for production.
// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <string>
#include <deque>
#include <vector>
#include <map>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cstdint>

#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define SERIAL_8N1 0
#define FILE_READ "r"
#define FILE_WRITE "w"
#define FILE_APPEND "a"

class String {
 public:
  std::string s;
  String() {}
  String(const char* c) : s(c ? c : "") {}
  String(const std::string& x) : s(x) {}
  String(char c) : s(1, c) {}
  String(int v) : s(std::to_string(v)) {}
  String(unsigned v) : s(std::to_string(v)) {}
  String(long v) : s(std::to_string(v)) {}
  String(unsigned long v) : s(std::to_string(v)) {}
  unsigned length() const { return (unsigned)s.size(); }
  const char* c_str() const { return s.c_str(); }
  int indexOf(char c, unsigned from = 0) const { size_t p = s.find(c, from); return p == std::string::npos ? -1 : (int)p; }
  int indexOf(const char* c, unsigned from = 0) const { size_t p = s.find(c, from); return p == std::string::npos ? -1 : (int)p; }
  int indexOf(const String& c, unsigned from = 0) const { return indexOf(c.c_str(), from); }
  String substring(unsigned a) const { return a >= s.size() ? String() : String(s.substr(a)); }
  String substring(unsigned a, unsigned b) const { if (a >= s.size() || b <= a) return String(); return String(s.substr(a, b - a)); }
  bool startsWith(const char* p) const { return s.rfind(p, 0) == 0; }
  bool startsWith(const String& p) const { return startsWith(p.c_str()); }
  void trim() { size_t a = s.find_first_not_of(" \t\r\n"); size_t b = s.find_last_not_of(" \t\r\n"); s = a == std::string::npos ? "" : s.substr(a, b - a + 1); }
  void toUpperCase() { for (auto& c : s) c = (char)toupper((unsigned char)c); }
  long toInt() const { return atol(s.c_str()); }
  String& operator+=(const String& o) { s += o.s; return *this; }
  String& operator+=(const char* o) { s += o; return *this; }
  String& operator+=(char c) { s += c; return *this; }
  bool operator==(const char* o) const { return s == o; }
  bool operator==(const String& o) const { return s == o.s; }
};
inline String operator+(const String& a, const String& b) { return String(a.s + b.s); }
inline String operator+(const String& a, const char* b) { return String(a.s + b); }
inline String operator+(const char* a, const String& b) { return String(std::string(a) + b.s); }
inline String operator+(const String& a, long b) { return String(a.s + std::to_string(b)); }
inline String operator+(const String& a, int b) { return String(a.s + std::to_string(b)); }
inline String operator+(const String& a, char b) { return String(a.s + b); }

// ---- time / gpio
unsigned long millis();
void delay(unsigned long ms);
void pinMode(int, int);
void digitalWrite(int, int);
int digitalRead(int pin);

// ---- serial
class HardwareSerial {
 public:
  explicit HardwareSerial(int n = 0) : n_(n) {}
  void begin(long, int = 0, int = 0, int = 0) {}
  int available();
  int read();
  void print(const String& x);
  void print(const char* x) { print(String(x)); }
  void println(const String& x) { print(x + "\r\n"); }
  void println(const char* x) { println(String(x)); }
  void write(uint8_t c) { print(String((char)c)); }
 private:
  int n_;
};
extern HardwareSerial Serial;
