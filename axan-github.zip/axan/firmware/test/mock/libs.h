// Mocks for ESP32Servo, LittleFS, Preferences and mbedtls used by axan.ino.
// SPDX-License-Identifier: Apache-2.0
#pragma once
#include "Arduino.h"

class Servo {
 public:
  void attach(int pin) { pin_ = pin; }
  void write(int deg);
  int pin_ = -1;
};

class File {
 public:
  File() {}
  File(std::string* buf, size_t pos, bool ok) : buf_(buf), pos_(pos), ok_(ok) {}
  explicit operator bool() const { return ok_; }
  size_t size() const { return buf_ ? buf_->size() : 0; }
  bool available() const { return buf_ && pos_ < buf_->size(); }
  int read() { return available() ? (unsigned char)(*buf_)[pos_++] : -1; }
  String readStringUntil(char t) { std::string r; while (available()) { char c = (char)read(); if (c == t) break; r += c; } return String(r); }
  void print(const String& s) { if (buf_) *buf_ += s.s; }
  void println(const String& s) { print(s + "\n"); }
  void close() {}
 private:
  std::string* buf_ = nullptr;
  size_t pos_ = 0;
  bool ok_ = false;
};

class FS {
 public:
  bool begin(bool) { return true; }
  File open(const char* path, const char* mode) {
    std::string& b = files[path];
    if (mode[0] == 'w') b.clear();
    return File(&b, 0, true);
  }
  std::map<std::string, std::string> files;
};
extern FS LittleFS;

class Preferences {
 public:
  bool begin(const char*, bool) { return true; }
  size_t putBytes(const char* k, const void* v, size_t n) { kv[k] = std::string((const char*)v, n); return n; }
  size_t getBytesLength(const char* k) { return kv.count(k) ? kv[k].size() : 0; }
  size_t getBytes(const char* k, void* v, size_t n) { memcpy(v, kv[k].data(), n); return n; }
  size_t putUInt(const char* k, uint32_t v) { return putBytes(k, &v, 4); }
  uint32_t getUInt(const char* k, uint32_t d) { uint32_t v = d; if (getBytesLength(k) == 4) getBytes(k, &v, 4); return v; }
  size_t putInt(const char* k, int32_t v) { return putBytes(k, &v, 4); }
  int32_t getInt(const char* k, int32_t d) { int32_t v = d; if (getBytesLength(k) == 4) getBytes(k, &v, 4); return v; }
  std::map<std::string, std::string> kv;
};

// Not real SHA-256: deterministic stand-in for host tests only.
inline int mbedtls_sha256(const unsigned char* in, size_t n, unsigned char out[32], int) {
  uint64_t h = 1469598103934665603ull;
  for (size_t i = 0; i < n; ++i) { h ^= in[i]; h *= 1099511628211ull; }
  for (int i = 0; i < 32; ++i) out[i] = (unsigned char)(h >> ((i % 8) * 8));
  return 0;
}
