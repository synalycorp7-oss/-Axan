// End-to-end simulation of the firmware on a PC: a fake SIM800L answers AT
// commands, fake SMS are injected, and the servo/IR sensor are simulated.
//   make -C firmware test
// SPDX-License-Identifier: Apache-2.0
#include "Arduino.h"
#include "libs.h"

// ------------------------------------------------------------ mock hardware
static unsigned long g_ms = 0;
unsigned long millis() { return ++g_ms; }
void delay(unsigned long ms) { g_ms += ms; }
void pinMode(int, int) {}
void digitalWrite(int, int) {}
static int g_jammedPin = -1;       // servo pin that is mechanically blocked
static bool g_dropPending = false;  // product currently falling through the IR beam
static int g_buttonDown = -1;       // button pin held down
static int g_dispensed = 0;
int digitalRead(int pin) {
  if (pin == 34) { if (g_dropPending) { g_dropPending = false; return LOW; } return HIGH; }
  if (pin == g_buttonDown) { g_buttonDown = -1; return LOW; }
  return HIGH;
}
void Servo::write(int deg) { if (deg > 45 && pin_ != g_jammedPin) { g_dropPending = true; ++g_dispensed; } }
FS LittleFS;

// Fake modem
static std::deque<char> g_rx;
static std::string g_line;
static std::vector<std::string> g_smsSent;
static std::vector<std::string> g_httpPosts;
static std::string g_pendingSmsTo, g_httpData;
static size_t g_httpDataLen = 0;
static bool g_networkUp = true;
static void reply(const std::string& s) { for (char c : s) g_rx.push_back(c); }
static void onCommand(const std::string& cmd) {
  if (cmd.rfind("AT+CCLK?", 0) == 0) reply("\r\n+CCLK: \"26/11/07,05:17:00+00\"\r\nOK\r\n");
  else if (cmd.rfind("AT+CSQ", 0) == 0) reply("\r\n+CSQ: 18,0\r\nOK\r\n");
  else if (cmd.rfind("AT+CMGS=", 0) == 0) { g_pendingSmsTo = cmd.substr(9, cmd.size() - 10); reply("\r\n> "); }
  else if (cmd.rfind("AT+HTTPDATA=", 0) == 0) { g_httpDataLen = atoi(cmd.c_str() + 12); g_httpData.clear(); reply("\r\nDOWNLOAD\r\n"); }
  else if (cmd.rfind("AT+HTTPACTION=1", 0) == 0) {
    reply("\r\nOK\r\n");
    if (g_networkUp) { g_httpPosts.push_back(g_httpData); reply("\r\n+HTTPACTION: 1,200,2\r\n"); }
    else reply("\r\n+HTTPACTION: 1,601,0\r\n");
  } else reply("\r\nOK\r\n");
}
HardwareSerial Serial(0);
int HardwareSerial::available() { return n_ == 2 ? (int)g_rx.size() : 0; }
int HardwareSerial::read() { if (n_ != 2 || g_rx.empty()) return -1; char c = g_rx.front(); g_rx.pop_front(); return (unsigned char)c; }
void HardwareSerial::print(const String& x) {
  if (n_ != 2) { return; }  // debug Serial: silent
  for (char c : x.s) {
    if (g_httpDataLen > 0) { g_httpData += c; if (g_httpData.size() == g_httpDataLen) { g_httpDataLen = 0; reply("\r\nOK\r\n"); } continue; }
    if (!g_pendingSmsTo.empty() && c == 26) { g_smsSent.push_back(g_pendingSmsTo + " | " + g_line); g_line.clear(); g_pendingSmsTo.clear(); reply("\r\n+CMGS: 1\r\n\r\nOK\r\n"); continue; }
    if (c == '\n') continue;
    if (c == '\r') { if (g_pendingSmsTo.empty()) { if (!g_line.empty()) onCommand(g_line); g_line.clear(); } continue; }
    g_line += c;
  }
}

// ------------------------------------------------------------ firmware under test
#include "../axan/axan.ino"

// ------------------------------------------------------------ scenario
static int failures = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++failures; } } while (0)

static void incomingSms(const char* sender, const char* body) {
  reply(std::string("\r\n+CMT: \"") + sender + "\",\"\",\"26/11/07,05:20:00+00\"\r\n" + body + "\r\n");
  for (int i = 0; i < 5; ++i) loop();
}
static std::string queue() { return LittleFS.files[QUEUE_FILE]; }
static int countIn(const std::string& s, const std::string& what) { int n = 0; size_t p = 0; while ((p = s.find(what, p)) != std::string::npos) { ++n; ++p; } return n; }

int main() {
  g_networkUp = false;  // start offline: machine must still work
  setup();
  loop();
  CHECK(stock[0] == 50 && stock[1] == 40 && stock[2] == 40);

  // 1. Fake payment SMS sent from an ordinary phone number -> rejected, nothing dispensed.
  incomingSms("+22670111111", "Vous avez recu 300 FCFA du 70111111. Ref: PP231107.0520.F00001");
  CHECK(g_dispensed == 0);
  CHECK(countIn(queue(), "\"sms_rejected\"") == 1);

  // 2. Genuine Orange Money SMS -> sale of product 1 (price 300).
  incomingSms("OrangeMoney", "Vous avez recu 300 FCFA du 70123456. Ref: PP231107.0521.A12345. Nouveau solde: 12 800 FCFA.");
  CHECK(g_dispensed == 1);
  CHECK(stock[0] == 49);
  CHECK(countIn(queue(), "\"sale\"") == 1);
  CHECK(queue().find("70123456") == std::string::npos);  // payer number never stored in clear

  // 3. Same SMS replayed -> blocked.
  incomingSms("OrangeMoney", "Vous avez recu 300 FCFA du 70123456. Ref: PP231107.0521.A12345. Nouveau solde: 12 800 FCFA.");
  CHECK(g_dispensed == 1);
  CHECK(countIn(queue(), "\"replay_blocked\"") == 1);

  // 4. Button "sanitary pads" then 500 F payment -> product 3.
  g_buttonDown = PRODUCTS[2].buttonPin; loop();
  incomingSms("MoovMoney", "Transfert recu de 22676543210 montant 500 F CFA. Trans ID: MP2311071234567");
  CHECK(stock[2] == 39);

  // 5. Jammed mechanism on product 2 -> failure logged, manager alerted with refund info.
  g_jammedPin = PRODUCTS[1].servoPin;
  incomingSms("MoovMoney", "Transfert recu de 22676000000 montant 500 F CFA. Trans ID: MP2311071239999");
  CHECK(slotFault[1]);
  CHECK(stock[1] == 40);
  CHECK(!g_smsSent.empty() && g_smsSent.back().find("Rembourser ref MP2311071239999") != std::string::npos);

  // 6. Wrong amount -> refund alert, no dispense.
  int before = g_dispensed;
  incomingSms("OrangeMoney", "Vous avez recu 250 FCFA du 70999999. Ref: PP231107.0530.B77777");
  CHECK(g_dispensed == before);
  CHECK(countIn(queue(), "\"amount_mismatch\"") == 1);

  // 7. Manager fixes the jam and refills product 2 by SMS.
  g_jammedPin = -1;
  incomingSms(MANAGER_NUMBER, "RECHARGE 2 40");
  CHECK(!slotFault[1] && stock[1] == 40);
  incomingSms("+22699999999", "RECHARGE 1 50");  // stranger cannot refill
  CHECK(stock[0] == 49);

  // 8. Network comes back -> queued events uploaded, queue emptied.
  g_networkUp = true;
  lastSync = 0; g_ms += SYNC_INTERVAL_MS + 1;
  loop();
  CHECK(!g_httpPosts.empty());
  CHECK(queue().empty());
  std::string all; for (auto& p : g_httpPosts) all += p;
  CHECK(all.find("\"machine_id\":\"AXN-OUA-001\"") != std::string::npos);
  CHECK(countIn(all, "\"sale\"") == 2);
  CHECK(all.find("2026-11-07T05:17:00") != std::string::npos);

  printf("SMS sent to manager:\n");
  for (auto& s : g_smsSent) printf("  %s\n", s.c_str());
  printf("Uploaded %zu batch(es), %d sale events.\n", g_httpPosts.size(), countIn(all, "\"sale\""));
  if (failures == 0) printf("All firmware simulation tests passed.\n");
  return failures == 0 ? 0 : 1;
}
