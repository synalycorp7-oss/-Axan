// Axan - mobile money condom & sanitary product vending machine
// Board: ESP32 + SIM800L (GSM/GPRS) + one servo per product + IR drop sensor.
//
// Payment flow (works 100% offline, no internet needed):
//   1. (optional) user presses the product button
//   2. user pays the machine's mobile money number (QR code / USSD on the front)
//   3. the operator sends a confirmation SMS to the machine's SIM
//   4. the firmware checks the sender, parses amount + reference, blocks replays
//   5. the servo pushes the product, the IR sensor confirms the drop
//   6. every event is queued in flash and uploaded to the server when GPRS is available
//
// Libraries: ESP32Servo (Kevin Harrington). LittleFS, Preferences, mbedtls ship with the ESP32 core.
// SPDX-License-Identifier: Apache-2.0

#include <Arduino.h>
#include <ESP32Servo.h>
#include <LittleFS.h>
#include <Preferences.h>
#include "mbedtls/sha256.h"
#include "config.h"
#include "sms_parser.h"

using namespace axan;

HardwareSerial modem(2);
Servo servos[N_PRODUCTS];
Preferences prefs;
ReplayGuard replay;

int stock[N_PRODUCTS];
bool slotFault[N_PRODUCTS];
bool lowStockAlertSent[N_PRODUCTS];
uint32_t eventSeq = 0;
int selectedSlot = -1;
unsigned long selectedAt = 0;
unsigned long lastSync = 0;

static const char* QUEUE_FILE = "/queue.jsonl";

// ------------------------------------------------------------------ utils

#define COUNT(a) ((int)(sizeof(a) / sizeof((a)[0])))

void beep(int times) {
  for (int i = 0; i < times; ++i) {
    digitalWrite(BUZZER_PIN, HIGH); digitalWrite(LED_PIN, HIGH); delay(80);
    digitalWrite(BUZZER_PIN, LOW);  digitalWrite(LED_PIN, LOW);  delay(80);
  }
}

// Payer numbers are personal data: only a salted SHA-256 prefix leaves the machine.
String hashPayer(const char* number) {
  if (!number || !*number) return "";
  String input = String(PAYER_HASH_SALT) + number;
  uint8_t out[32];
  mbedtls_sha256((const unsigned char*)input.c_str(), input.length(), out, 0);
  char hex[17];
  for (int i = 0; i < 8; ++i) sprintf(hex + 2 * i, "%02x", out[i]);
  return String(hex);
}

// ------------------------------------------------------------------ modem

String modemReadLine(unsigned long timeoutMs) {
  String line;
  unsigned long start = millis();
  while (millis() - start < timeoutMs) {
    while (modem.available()) {
      char c = modem.read();
      if (c == '\n') { line.trim(); if (line.length()) return line; }
      else if (c != '\r') line += c;
    }
    delay(1);
  }
  line.trim();
  return line;
}

// Sends an AT command and waits for `expect` (or ERROR). Returns full response.
String at(const String& cmd, const char* expect = "OK", unsigned long timeoutMs = 2000) {
  while (modem.available()) modem.read();
  modem.println(cmd);
  String resp;
  unsigned long start = millis();
  while (millis() - start < timeoutMs) {
    while (modem.available()) resp += (char)modem.read();
    if (resp.indexOf(expect) >= 0 || resp.indexOf("ERROR") >= 0) break;
    delay(5);
  }
  return resp;
}

String networkTime() {
  // +CCLK: "26/11/07,05:17:00+00"
  String r = at("AT+CCLK?");
  int q = r.indexOf('"');
  if (q < 0 || r.length() < (unsigned)q + 18) return "";
  String t = r.substring(q + 1, q + 18);
  if (t.startsWith("04/01/01") || t.startsWith("80/01/01")) return "";  // clock not set yet
  return "20" + t.substring(0, 2) + "-" + t.substring(3, 5) + "-" + t.substring(6, 8) + "T" + t.substring(9, 17);
}

int signalQuality() {
  String r = at("AT+CSQ");
  int i = r.indexOf("+CSQ: ");
  return i < 0 ? -1 : r.substring(i + 6).toInt();
}

bool sendSms(const char* number, const String& text) {
  at("AT+CMGF=1");
  String r = at(String("AT+CMGS=\"") + number + "\"", ">", 5000);
  if (r.indexOf('>') < 0) return false;
  modem.print(text.substring(0, 159));
  modem.write(26);  // Ctrl-Z
  r = at("", "+CMGS", 15000);
  return r.indexOf("+CMGS") >= 0;
}

void modemSetup() {
  modem.begin(MODEM_BAUD, SERIAL_8N1, MODEM_RX_PIN, MODEM_TX_PIN);
  delay(3000);
  at("AT");
  at("ATE0");
  at("AT+CLTS=1");           // network time
  at("AT+CMGF=1");           // SMS text mode
  at("AT+CSCS=\"GSM\"");
  at("AT+CNMI=2,2,0,0,0");   // push incoming SMS directly as +CMT
  at("AT+CMGDA=\"DEL ALL\"", "OK", 5000);  // keep SIM storage free
}

// ------------------------------------------------------------------ persistence

void saveState() {
  prefs.putBytes("stock", stock, sizeof(stock));
  prefs.putBytes("fault", slotFault, sizeof(slotFault));
  prefs.putUInt("seq", eventSeq);
  prefs.putBytes("replay", replay.data(), sizeof(uint32_t) * ReplayGuard::CAPACITY);
  prefs.putInt("rhead", replay.head());
}

void loadState() {
  for (int i = 0; i < N_PRODUCTS; ++i) { stock[i] = PRODUCTS[i].capacity; slotFault[i] = false; lowStockAlertSent[i] = false; }
  if (prefs.getBytesLength("stock") == sizeof(stock)) prefs.getBytes("stock", stock, sizeof(stock));
  if (prefs.getBytesLength("fault") == sizeof(slotFault)) prefs.getBytes("fault", slotFault, sizeof(slotFault));
  eventSeq = prefs.getUInt("seq", 0);
  uint32_t buf[ReplayGuard::CAPACITY];
  if (prefs.getBytesLength("replay") == sizeof(buf)) {
    prefs.getBytes("replay", buf, sizeof(buf));
    replay.load(buf, ReplayGuard::CAPACITY, prefs.getInt("rhead", 0));
  }
}

// One JSON object per line; uploaded in batches, removed once the server acknowledges.
void logEvent(const char* type, int slot, long amount, const char* ref, const String& payerHash, const char* detail) {
  ++eventSeq;
  String json = "{\"seq\":" + String(eventSeq) + ",\"ts\":\"" + networkTime() + "\",\"uptime\":" + String(millis() / 1000) +
                ",\"type\":\"" + type + "\",\"slot\":" + String(slot) + ",\"amount\":" + String(amount);
  if (ref && *ref) json += ",\"ref\":\"" + String(ref) + "\"";
  if (payerHash.length()) json += ",\"payer\":\"" + payerHash + "\"";
  if (detail && *detail) json += ",\"detail\":\"" + String(detail) + "\"";
  json += ",\"stock\":[";
  for (int i = 0; i < N_PRODUCTS; ++i) json += String(stock[i]) + (i + 1 < N_PRODUCTS ? "," : "");
  json += "]}";
  File f = LittleFS.open(QUEUE_FILE, FILE_APPEND);
  if (f) { f.println(json); f.close(); }
  Serial.println(json);
  saveState();
}

// ------------------------------------------------------------------ dispensing

bool waitForDrop() {
  unsigned long start = millis();
  while (millis() - start < DROP_TIMEOUT_MS) {
    if (digitalRead(DROP_SENSOR_PIN) == DROP_SENSOR_ACTIVE) return true;
    delay(2);
  }
  return false;
}

bool dispense(int slot) {
  for (int attempt = 0; attempt <= DISPENSE_RETRIES; ++attempt) {
    servos[slot].write(SERVO_PUSH_DEG);
    delay(SERVO_PUSH_MS);
    servos[slot].write(SERVO_REST_DEG);
    if (waitForDrop()) return true;
  }
  return false;
}

void checkLowStock(int slot) {
  if (stock[slot] <= LOW_STOCK_THRESHOLD && !lowStockAlertSent[slot]) {
    sendSms(MANAGER_NUMBER, String("Axan ") + MACHINE_ID + ": stock bas " + PRODUCTS[slot].name + " (" + stock[slot] + ")");
    lowStockAlertSent[slot] = true;
  }
}

// ------------------------------------------------------------------ SMS handling

void handlePaymentSms(const String& sender, const String& body) {
  Payment p;
  bool trusted = isTrustedSender(sender.c_str(), TRUSTED_SENDERS, COUNT(TRUSTED_SENDERS));
  Verdict v = parsePayment(body.c_str(), PAYMENT_KEYWORDS, COUNT(PAYMENT_KEYWORDS), &p);

  if (!trusted) {
    if (v == PAY_OK) {
      // Looks like a payment but comes from an ordinary number: classic fake-SMS fraud.
      logEvent("sms_rejected", -1, p.amount, p.ref, hashPayer(sender.c_str()), "untrusted_sender");
      beep(3);
    }
    return;  // ignore other SMS (promotions, etc.)
  }
  if (v != PAY_OK) {
    if (v != REJECT_NOT_PAYMENT) logEvent("sms_unparsed", -1, p.amount, p.ref, "", verdictName(v));
    return;
  }
  if (replay.seen(p.ref)) {
    logEvent("replay_blocked", -1, p.amount, p.ref, hashPayer(p.payer), "replay");
    return;
  }
  replay.remember(p.ref);

  long prices[N_PRODUCTS];
  for (int i = 0; i < N_PRODUCTS; ++i) prices[i] = PRODUCTS[i].price;
  int sel = (selectedSlot >= 0 && millis() - selectedAt < SELECTION_TIMEOUT_MS) ? selectedSlot : -1;
  int slot = resolveProduct(p.amount, sel, prices, N_PRODUCTS);
  selectedSlot = -1;
  String payerHash = hashPayer(p.payer);

  if (slot < 0) {
    logEvent("amount_mismatch", sel, p.amount, p.ref, payerHash, "refund_needed");
    sendSms(MANAGER_NUMBER, String("Axan ") + MACHINE_ID + ": montant " + p.amount + "F ne correspond a aucun produit. Ref " + p.ref + " client " + p.payer + " (a rembourser)");
    beep(2);
    return;
  }
  if (stock[slot] <= 0 || slotFault[slot]) {
    logEvent("dispense_failed", slot, p.amount, p.ref, payerHash, stock[slot] <= 0 ? "empty" : "slot_fault");
    sendSms(MANAGER_NUMBER, String("Axan ") + MACHINE_ID + ": " + PRODUCTS[slot].name + " indisponible. Rembourser ref " + p.ref + " client " + p.payer);
    beep(2);
    return;
  }
  if (dispense(slot)) {
    stock[slot]--;
    logEvent("sale", slot, p.amount, p.ref, payerHash, "");
    beep(1);
    checkLowStock(slot);
  } else {
    slotFault[slot] = true;
    logEvent("dispense_failed", slot, p.amount, p.ref, payerHash, "no_drop_detected");
    sendSms(MANAGER_NUMBER, String("Axan ") + MACHINE_ID + ": blocage " + PRODUCTS[slot].name + ". Rembourser ref " + p.ref + " client " + p.payer);
    beep(2);
  }
}

// Commands from the manager's number only:  RECHARGE <n> <qty> | ETAT | TEST <n>
void handleManagerSms(const String& bodyRaw) {
  String body = bodyRaw; body.trim(); body.toUpperCase();
  if (body.startsWith("RECHARGE")) {
    int a = body.indexOf(' '), b = body.indexOf(' ', a + 1);
    int slot = body.substring(a + 1, b).toInt() - 1, qty = body.substring(b + 1).toInt();
    if (slot >= 0 && slot < N_PRODUCTS && qty >= 0 && qty <= PRODUCTS[slot].capacity) {
      stock[slot] = qty; slotFault[slot] = false; lowStockAlertSent[slot] = false;
      logEvent("refill", slot, 0, "", "", "");
      sendSms(MANAGER_NUMBER, String("OK ") + PRODUCTS[slot].name + " = " + qty);
    } else {
      sendSms(MANAGER_NUMBER, "Format: RECHARGE <produit 1-" + String(N_PRODUCTS) + "> <quantite>");
    }
  } else if (body.startsWith("ETAT")) {
    String s = String(MACHINE_ID) + " CSQ" + signalQuality();
    for (int i = 0; i < N_PRODUCTS; ++i) s += String(" P") + (i + 1) + "=" + stock[i] + (slotFault[i] ? "!" : "");
    sendSms(MANAGER_NUMBER, s);
  } else if (body.startsWith("TEST")) {
    int slot = body.substring(5).toInt() - 1;
    if (slot >= 0 && slot < N_PRODUCTS) {
      bool ok = dispense(slot);
      if (ok) { stock[slot]--; slotFault[slot] = false; }
      logEvent("test_dispense", slot, 0, "", "", ok ? "ok" : "no_drop_detected");
      sendSms(MANAGER_NUMBER, String("TEST ") + (slot + 1) + (ok ? " OK" : " ECHEC"));
    }
  }
}

void pollModem() {
  if (!modem.available()) return;
  String line = modemReadLine(200);
  if (!line.startsWith("+CMT:")) return;
  // +CMT: "OrangeMoney","","26/11/07,05:17:00+00"
  int q1 = line.indexOf('"'), q2 = line.indexOf('"', q1 + 1);
  String sender = (q1 >= 0 && q2 > q1) ? line.substring(q1 + 1, q2) : "";
  String body, next;
  unsigned long start = millis();
  while (millis() - start < 400 && (next = modemReadLine(150)).length()) { body += (body.length() ? " " : "") + next; start = millis(); }
  if (sender == MANAGER_NUMBER) handleManagerSms(body);
  else handlePaymentSms(sender, body);
}

// ------------------------------------------------------------------ buttons

void pollButtons() {
  for (int i = 0; i < N_PRODUCTS; ++i) {
    if (digitalRead(PRODUCTS[i].buttonPin) == LOW) {
      selectedSlot = i; selectedAt = millis();
      beep(1);
      delay(250);  // debounce
    }
  }
}

// ------------------------------------------------------------------ sync (GPRS HTTP)

bool httpPost(const String& payload) {
  at("AT+SAPBR=3,1,\"Contype\",\"GPRS\"");
  at(String("AT+SAPBR=3,1,\"APN\",\"") + APN + "\"");
  at("AT+SAPBR=1,1", "OK", 10000);
  at("AT+HTTPTERM");
  at("AT+HTTPINIT");
  at("AT+HTTPPARA=\"CID\",1");
  at(String("AT+HTTPPARA=\"URL\",\"") + SERVER_URL + "\"");
  at("AT+HTTPPARA=\"CONTENT\",\"application/json\"");
  at(String("AT+HTTPPARA=\"USERDATA\",\"X-API-Key: ") + API_KEY + "\"");
  String r = at("AT+HTTPDATA=" + String(payload.length()) + ",10000", "DOWNLOAD", 5000);
  bool ok = false;
  if (r.indexOf("DOWNLOAD") >= 0) {
    modem.print(payload);
    at("", "OK", 5000);
    r = at("AT+HTTPACTION=1", "+HTTPACTION:", 30000);
    ok = r.indexOf(",200,") >= 0;
  }
  at("AT+HTTPTERM");
  at("AT+SAPBR=0,1", "OK", 5000);
  return ok;
}

// Upload queued events in batches of 20 lines; keep the rest for next time.
void syncEvents() {
  logEvent("heartbeat", -1, signalQuality(), "", "", "");
  for (int round = 0; round < 10; ++round) {
    File f = LittleFS.open(QUEUE_FILE, FILE_READ);
    if (!f || f.size() == 0) { if (f) f.close(); return; }
    String batch; int n = 0;
    while (f.available() && n < 20) { String l = f.readStringUntil('\n'); l.trim(); if (l.length()) { batch += (n ? "," : "") + l; ++n; } }
    String rest;
    while (f.available()) rest += (char)f.read();
    f.close();
    String payload = String("{\"machine_id\":\"") + MACHINE_ID + "\",\"events\":[" + batch + "]}";
    if (!httpPost(payload)) return;  // offline: retry at next interval, nothing is lost
    File w = LittleFS.open(QUEUE_FILE, FILE_WRITE);
    if (w) { w.print(rest); w.close(); }
  }
}

// ------------------------------------------------------------------ main

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT); pinMode(BUZZER_PIN, OUTPUT);
  pinMode(DROP_SENSOR_PIN, INPUT);
  for (int i = 0; i < N_PRODUCTS; ++i) {
    pinMode(PRODUCTS[i].buttonPin, INPUT_PULLUP);
    servos[i].attach(PRODUCTS[i].servoPin);
    servos[i].write(SERVO_REST_DEG);
  }
  LittleFS.begin(true);
  prefs.begin("axan", false);
  loadState();
  modemSetup();
  logEvent("boot", -1, 0, "", "", "");
  beep(2);
}

void loop() {
  pollModem();
  pollButtons();
  if (millis() - lastSync > SYNC_INTERVAL_MS || lastSync == 0) {
    lastSync = millis();
    syncEvents();
  }
}
