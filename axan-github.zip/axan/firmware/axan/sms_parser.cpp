// SPDX-License-Identifier: Apache-2.0
#include "sms_parser.h"
#include <string.h>
#include <ctype.h>

namespace axan {

const char* verdictName(Verdict v) {
  switch (v) {
    case PAY_OK: return "ok";
    case REJECT_UNTRUSTED_SENDER: return "untrusted_sender";
    case REJECT_NOT_PAYMENT: return "not_payment";
    case REJECT_NO_AMOUNT: return "no_amount";
    case REJECT_NO_REF: return "no_ref";
    case REJECT_REPLAY: return "replay";
  }
  return "unknown";
}

static char lower(char c) { return (char)tolower((unsigned char)c); }
static bool isAlnum(char c) { return isalnum((unsigned char)c) != 0; }
static bool isDigit(char c) { return c >= '0' && c <= '9'; }

static bool ieq(const char* a, const char* b) {
  while (*a && *b) {
    if (lower(*a) != lower(*b)) return false;
    ++a; ++b;
  }
  return *a == 0 && *b == 0;
}

// Case-insensitive substring search (ASCII); returns pointer into hay or NULL.
static const char* ifind(const char* hay, const char* needle) {
  size_t n = strlen(needle);
  if (n == 0) return hay;
  for (const char* p = hay; *p; ++p) {
    size_t i = 0;
    while (i < n && p[i] && lower(p[i]) == lower(needle[i])) ++i;
    if (i == n) return p;
  }
  return NULL;
}

bool isTrustedSender(const char* sender, const char* const* trusted, int nTrusted) {
  if (!sender || !*sender) return false;
  for (int i = 0; i < nTrusted; ++i) {
    if (ieq(sender, trusted[i])) return true;
  }
  return false;
}

// Is there a currency marker at p (after optional spaces)? Returns length consumed or 0.
static int currencyAt(const char* p) {
  while (*p == ' ') ++p;
  static const char* const cur[] = {"FCFA", "F CFA", "F.CFA", "XOF", "CFA", "F"};
  for (size_t i = 0; i < sizeof(cur) / sizeof(cur[0]); ++i) {
    size_t n = strlen(cur[i]);
    bool match = true;
    for (size_t k = 0; k < n; ++k) {
      if (!p[k] || lower(p[k]) != lower(cur[i][k])) { match = false; break; }
    }
    if (match && !isAlnum(p[n])) return (int)n;
  }
  return 0;
}

// Parses a number at p with thousand separators (space, dot, comma, NBSP-free).
// Sets *end past the number. Decimals (1-2 digits after a separator) are dropped.
static long readAmount(const char* p, const char** end) {
  long value = 0;
  while (isDigit(*p)) { value = value * 10 + (*p - '0'); ++p; }
  for (;;) {
    if ((*p == ' ' || *p == '.' || *p == ',') && isDigit(p[1]) && isDigit(p[2]) && isDigit(p[3]) && !isDigit(p[4])) {
      value = value * 1000 + (p[1] - '0') * 100 + (p[2] - '0') * 10 + (p[3] - '0');
      p += 4;
    } else if ((*p == '.' || *p == ',') && isDigit(p[1]) && (!isDigit(p[2]) || !isDigit(p[3]))) {
      ++p;  // decimals: skip
      while (isDigit(*p)) ++p;
      break;
    } else {
      break;
    }
  }
  *end = p;
  return value;
}

static long findAmount(const char* body) {
  for (const char* p = body; *p; ++p) {
    if (isDigit(*p) && (p == body || !isAlnum(p[-1]))) {
      const char* end;
      long v = readAmount(p, &end);
      if (v > 0 && currencyAt(end)) return v;
      p = end - 1 >= p ? end - 1 : p;
    }
  }
  return 0;
}

static bool tokenHasDigit(const char* s, size_t n) {
  for (size_t i = 0; i < n; ++i) if (isDigit(s[i])) return true;
  return false;
}

static bool isRefChar(char c) { return isAlnum(c) || c == '.' || c == '-' || c == '_'; }

static bool wordIs(const char* w, size_t n, const char* const* list, size_t count) {
  for (size_t i = 0; i < count; ++i) {
    if (strlen(list[i]) != n) continue;
    size_t k = 0;
    while (k < n && lower(w[k]) == list[i][k]) ++k;
    if (k == n) return true;
  }
  return false;
}

static bool isRefKeyword(const char* w, size_t n) {
  static const char* const keys[] = {"ref", "reference", "id", "txn", "txnid", "tid", "trans", "transaction", "trx"};
  return wordIs(w, n, keys, sizeof(keys) / sizeof(keys[0]));
}

static bool isFiller(const char* w, size_t n) {
  static const char* const fill[] = {"no", "num", "n"};
  return wordIs(w, n, fill, sizeof(fill) / sizeof(fill[0]));
}

static bool findRef(const char* body, char* out) {
  // Scan word by word. A reference is the first token containing a digit that
  // directly follows a reference keyword (optionally "Trans ID", "Ref No", ":", "#").
  const char* p = body;
  while (*p) {
    while (*p && !isAlnum(*p)) ++p;
    const char* w = p;
    while (isAlnum(*p)) ++p;
    size_t wn = (size_t)(p - w);
    if (wn == 0) break;
    if (!isRefKeyword(w, wn)) continue;
    const char* q = p;
    for (int t = 0; t < 2; ++t) {              // allow one extra keyword word ("Trans ID")
      while (*q == ' ' || *q == ':' || *q == '#' || *q == '.' || *q == '-' || *q == '=') ++q;
      const char* s = q;
      while (isRefChar(*q)) ++q;
      size_t n = (size_t)(q - s);
      while (n > 0 && (s[n - 1] == '.' || s[n - 1] == '-')) --n;  // trailing punctuation
      if (n >= 4 && n < REF_MAX && tokenHasDigit(s, n)) {
        memcpy(out, s, n);
        out[n] = 0;
        return true;
      }
      if (!(n > 0 && (isRefKeyword(s, n) || isFiller(s, n)))) break;
    }
  }
  return false;
}

static bool containsSeq(const char* hay, const char* s, size_t n) {
  size_t h = strlen(hay);
  for (size_t i = 0; n > 0 && i + n <= h; ++i) {
    if (memcmp(hay + i, s, n) == 0) return true;
  }
  return false;
}

static void findPayer(const char* body, const char* ref, char* out) {
  out[0] = 0;
  for (const char* p = body; *p; ++p) {
    if (isDigit(*p) && (p == body || !isAlnum(p[-1]))) {
      const char* s = p;
      while (isDigit(*p)) ++p;
      size_t n = (size_t)(p - s);
      bool partOfRef = containsSeq(ref, s, n);
      if (n >= 8 && n <= 12 && !isAlnum(*p) && !(*p == '.' && isAlnum(p[1])) && !partOfRef) {
        memcpy(out, s, n);
        out[n] = 0;
        return;
      }
      if (!*p) return;
    }
  }
}

Verdict parsePayment(const char* body, const char* const* keywords, int nKeywords, Payment* out) {
  memset(out, 0, sizeof(*out));
  if (!body) return REJECT_NOT_PAYMENT;
  bool isPayment = false;
  for (int i = 0; i < nKeywords && !isPayment; ++i) {
    if (ifind(body, keywords[i])) isPayment = true;
  }
  if (!isPayment) return REJECT_NOT_PAYMENT;
  out->amount = findAmount(body);
  if (out->amount <= 0) return REJECT_NO_AMOUNT;
  if (!findRef(body, out->ref)) return REJECT_NO_REF;
  findPayer(body, out->ref, out->payer);
  return PAY_OK;
}

// ---------------- ReplayGuard ----------------

ReplayGuard::ReplayGuard() : head_(0) { memset(hashes_, 0, sizeof(hashes_)); }

uint32_t ReplayGuard::hash(const char* s) {
  uint32_t h = 2166136261u;  // FNV-1a
  for (; *s; ++s) { h ^= (uint8_t)lower(*s); h *= 16777619u; }
  return h == 0 ? 1 : h;     // 0 means "empty slot"
}

bool ReplayGuard::seen(const char* ref) const {
  uint32_t h = hash(ref);
  for (int i = 0; i < CAPACITY; ++i) if (hashes_[i] == h) return true;
  return false;
}

void ReplayGuard::remember(const char* ref) {
  hashes_[head_] = hash(ref);
  head_ = (head_ + 1) % CAPACITY;
}

void ReplayGuard::load(const uint32_t* hashes, int count, int head) {
  memset(hashes_, 0, sizeof(hashes_));
  if (count > CAPACITY) count = CAPACITY;
  memcpy(hashes_, hashes, (size_t)count * sizeof(uint32_t));
  head_ = (head >= 0 && head < CAPACITY) ? head : 0;
}

// ---------------- Product resolution ----------------

int resolveProduct(long amount, int selectedSlot, const long* prices, int nProducts) {
  if (selectedSlot >= 0 && selectedSlot < nProducts) {
    return amount >= prices[selectedSlot] ? selectedSlot : -1;
  }
  for (int i = 0; i < nProducts; ++i) {
    if (amount == prices[i]) return i;
  }
  return -1;
}

}  // namespace axan
