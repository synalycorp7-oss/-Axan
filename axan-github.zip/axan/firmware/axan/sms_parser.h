// Axan - mobile money SMS parsing and payment security.
// Pure C++ (no Arduino dependency) so it can be unit-tested on a PC:
//   g++ -std=c++11 -I firmware/axan firmware/test/test_sms_parser.cpp firmware/axan/sms_parser.cpp
//
// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace axan {

static const size_t REF_MAX = 32;
static const size_t PAYER_MAX = 20;

struct Payment {
  long amount;               // in FCFA
  char ref[REF_MAX];         // operator transaction reference
  char payer[PAYER_MAX];     // payer phone number (only kept in RAM, hashed before logging)
};

enum Verdict {
  PAY_OK = 0,
  REJECT_UNTRUSTED_SENDER,   // "payment" SMS sent from an ordinary number: fake SMS attempt
  REJECT_NOT_PAYMENT,        // not an incoming-payment SMS (promo, balance, etc.)
  REJECT_NO_AMOUNT,
  REJECT_NO_REF,
  REJECT_REPLAY              // transaction reference already used
};

const char* verdictName(Verdict v);

// True if the sender ID matches one of the official operator sender IDs
// (case-insensitive exact match). Ordinary phone numbers are never trusted
// unless they are explicitly listed.
bool isTrustedSender(const char* sender, const char* const* trusted, int nTrusted);

// Extract amount, transaction reference and payer number from an operator SMS.
// Formats differ between operators and change over time, so the parser is
// tolerant: amount = number followed by FCFA / F CFA / XOF / F, reference =
// token after Ref / ID / Trans / Transaction / Txn, payer = first 8-12 digit number.
// `keywords` must contain at least one word that proves this is an incoming
// payment (e.g. "recu", "reçu", "received", "transfert de").
Verdict parsePayment(const char* body, const char* const* keywords, int nKeywords, Payment* out);

// Ring buffer of hashed transaction references to block replayed SMS.
class ReplayGuard {
 public:
  static const int CAPACITY = 64;
  ReplayGuard();
  bool seen(const char* ref) const;
  void remember(const char* ref);
  // Raw access for persisting to flash (Preferences) on the ESP32.
  const uint32_t* data() const { return hashes_; }
  void load(const uint32_t* hashes, int count, int head);
  int head() const { return head_; }
  static uint32_t hash(const char* s);
 private:
  uint32_t hashes_[CAPACITY];
  int head_;
};

// Decide which product to dispense.
// selectedSlot: product chosen with the button before paying (-1 if none).
// Returns the slot index, or -1 if the amount does not match.
int resolveProduct(long amount, int selectedSlot, const long* prices, int nProducts);

}  // namespace axan
