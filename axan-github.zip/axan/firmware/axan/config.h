// Axan machine configuration. Copy to config.h and edit for each machine.
// SPDX-License-Identifier: Apache-2.0
#pragma once

// ---------- Identity ----------
#define MACHINE_ID        "AXN-OUA-001"
#define API_KEY           "change-me"            // issued by the server (manage.py add-machine)
#define PAYER_HASH_SALT   "change-me-too"        // secret salt: payer numbers are hashed, never sent in clear

// ---------- Network (SIM800L, GPRS) ----------
#define APN               "internet"             // operator APN
#define SERVER_URL        "http://your-server.example/api/v1/events"  // SIM800L: plain HTTP or a TLS proxy
#define SYNC_INTERVAL_MS  (15UL * 60UL * 1000UL) // heartbeat + upload every 15 min
#define MODEM_RX_PIN      16
#define MODEM_TX_PIN      17
#define MODEM_BAUD        9600

// ---------- Manager (human oversight) ----------
#define MANAGER_NUMBER    "+22600000000"         // receives alerts, may send RECHARGE / ETAT / TEST commands

// ---------- Payment security ----------
// Official sender IDs of operator payment SMS. Anything else is rejected and logged as fraud attempt.
static const char* const TRUSTED_SENDERS[] = {"OrangeMoney", "Orange Money", "MoovMoney", "Moov Money"};
// Words proving the SMS is an INCOMING payment (check against real SMS of each operator).
static const char* const PAYMENT_KEYWORDS[] = {"recu", "reçu", "received", "transfert de", "depot"};

// ---------- Products ----------
#define N_PRODUCTS 3
struct ProductConfig { const char* name; long price; int servoPin; int buttonPin; int capacity; };
static const ProductConfig PRODUCTS[N_PRODUCTS] = {
  // name                 price  servo button capacity
  {"Condoms x3",           300,   13,   32,    50},
  {"Female condom",        500,   14,   33,    40},
  {"Sanitary pads",        500,   27,   25,    40},
};
#define LOW_STOCK_THRESHOLD 8
#define SELECTION_TIMEOUT_MS (3UL * 60UL * 1000UL)  // a button selection is valid 3 minutes

// ---------- Dispensing ----------
#define SERVO_REST_DEG    0
#define SERVO_PUSH_DEG    95
#define SERVO_PUSH_MS     600
#define DROP_SENSOR_PIN   34      // IR beam at the output tray
#define DROP_SENSOR_ACTIVE LOW    // level when the beam is broken
#define DROP_TIMEOUT_MS   3000
#define DISPENSE_RETRIES  1
#define LED_PIN           2
#define BUZZER_PIN        26
